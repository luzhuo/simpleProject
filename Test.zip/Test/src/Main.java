public class Main {

    public static void main(String[] args) {

        System.out.println(3 & 4);//0011 0100
        System.out.println(4 & 4);//0100 0100
        System.out.println(2 & 3);//0010 0011
        System.out.print(5 & 4);// 0101 0100

    }

}
