package com.lz.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lz.Dao.ICatalogDao;
import com.lz.Dao.IProduceDao;
import com.lz.domain.PageBean;
import com.lz.entity.CatalogBean;
import com.lz.entity.ProduceBean;
import com.lz.util.DaoFactory;

public class ProduceAction extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private int rowsPerPage = 15;
	private IProduceDao pdao = DaoFactory.getIPaoduceDao();
	private ICatalogDao cdao = DaoFactory.getICatatlogDao();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PageBean pages = new PageBean();
		String cid = request.getParameter("cid");
		System.out.println("dddd:"+cid);
		Long catalogId = null;
		Integer pageNum = null;
		try {
			catalogId = Long.valueOf(cid.trim());
			CatalogBean load = cdao.load(catalogId);
			if (load != null)
				request.setAttribute("catalog", load);
		} catch (Exception e) {
			e.printStackTrace();
			catalogId = null;
		}
		System.out.println("cid:"+catalogId);
		cid = request.getParameter("page");
		try {
			pageNum = Integer.valueOf(cid.trim());
		} catch (Exception e) {
			pageNum = 1;
		}
		ProduceBean pb = new ProduceBean();
		pages.setPageNum(pageNum);
		pages.setRowPerPage(rowsPerPage);
		if (catalogId != null)
			pb.getCatalog().setId(catalogId);
		try {
			List<ProduceBean> plist = pdao.getProduce(pb, pages);
			request.setAttribute("pages", pages);
			request.setAttribute("produce", plist);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("produce/list.jsp").forward(request,
				response);
	}

	@Override
	public void init() throws ServletException {
		super.init();
		String ss = this.getServletConfig().getInitParameter("rowsPerPage");
		try {
			rowsPerPage = Integer.valueOf(ss.trim());
		} catch (Exception e) {
			rowsPerPage = 15;
		}

	}

}
