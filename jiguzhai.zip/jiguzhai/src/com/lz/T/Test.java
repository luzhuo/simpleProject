package com.lz.T;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.lz.entity.ProduceBean;
import com.lz.util.ConnectionMannage;

public class Test {
	public static void main(String[] args) throws Exception {
		List<ProduceBean> res = new ArrayList<ProduceBean>();
		Connection conn = null;
		conn = ConnectionMannage.getConnection();
		Statement cs = conn.createStatement();
		ResultSet rs = cs.executeQuery
				("select p.*,c.title ctitle,a.name from t_produce p left join t_author a on a.id=p.author_id left join t_catalog c on c.id=p.catalog_id");
		while(rs.next()){
			ProduceBean pb = new ProduceBean();
			pb.setId(rs.getLong("id"));
			pb.setPrice(rs.getDouble("price"));
			pb.setTiele(rs.getString("title"));
			pb.setSpec(rs.getString("spec"));
			pb.setPic(rs.getString("pic"));
			pb.setAuthor(rs.getString("name"));
			res.add(pb);
		}
		conn.close();
		cs.close();
		rs.close();
		for (ProduceBean p : res) {
			System.out.println(p.getPic());
			System.out.println(p.getPrice());
			System.out.println(p.getTiele());
			System.out.println(p.getAuthor());
			System.out.println(p.getSpec());
		}
	}

}
