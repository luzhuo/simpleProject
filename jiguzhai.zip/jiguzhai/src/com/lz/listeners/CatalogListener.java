package com.lz.listeners;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.lz.Dao.ICatalogDao;
import com.lz.entity.CatalogBean;
import com.lz.util.DaoFactory;

public class CatalogListener implements ServletContextListener{

	public void contextDestroyed(ServletContextEvent arg0) {
		ServletContext application = arg0.getServletContext();
		application.removeAttribute("cataloglist");
	}

	public void contextInitialized(ServletContextEvent arg0) {
		ServletContext application = arg0.getServletContext();
		ICatalogDao cdao = DaoFactory.getICatatlogDao();
		try {
			List<CatalogBean> clist = cdao.getAllCatalogs();
			application.setAttribute("cataloglist", clist);
		} catch (Exception e) {
			application.log(this.getClass().getName(),e);
		}
	}

}
