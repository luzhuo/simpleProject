package com.lz.listeners;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionListener implements HttpSessionListener,ServletContextListener {

	public void sessionCreated(HttpSessionEvent arg0) {//������ִ��	

		HttpSession session = arg0.getSession();
		ServletContext application = session.getServletContext();
		Long counter = 1000L;
		synchronized (application) {
			Object obj = application.getAttribute("counter");
			if(obj!=null&&obj instanceof Long)
				counter = (Long)obj;
			counter++;
			application.setAttribute("counter", counter);
		}
	}

	public void sessionDestroyed(HttpSessionEvent arg0) {//����ʱִ��

		HttpSession session = arg0.getSession();
		ServletContext application = session.getServletContext();
		Long counter = 1000L;
		synchronized (application) {
			Object obj = application.getAttribute("counter");
			if(obj!=null&&obj instanceof Long)
				counter = (Long)obj;
			counter--;
			if(counter<1L)
				counter=1L;
			application.setAttribute("counter", counter);
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		ServletContext appliaction = arg0.getServletContext();
		String Path = appliaction.getRealPath("");
		try {
			@SuppressWarnings("resource")
			DataOutputStream dos = new DataOutputStream(new FileOutputStream(new File(Path,"counter.data")));
			Object obj = appliaction.getAttribute("counter");
			if(obj!=null&&obj instanceof Long){
				Long ll = (Long)obj;
			dos.writeLong(ll);}
		} catch (Exception e) {
			appliaction.log(this.getClass().getName(),e);
		}
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		ServletContext appliaction = arg0.getServletContext();
		try {
			InputStream is = appliaction.getResourceAsStream("counter.data");
			DataInputStream dis = new DataInputStream(is);
			long counter = dis.readLong();
			appliaction.setAttribute("counter", counter);
		} catch (Exception e) {
			appliaction.log(this.getClass().getName(),e);
		}
	}

}
