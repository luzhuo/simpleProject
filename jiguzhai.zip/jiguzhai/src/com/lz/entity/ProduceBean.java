package com.lz.entity;

import java.io.Serializable;

public class ProduceBean implements Serializable{


	private static final long serialVersionUID = -4948359170098119883L;
	private Long id;
	private String tiele;
	private String spec;
	private double price;
	private String author;
	private CatalogBean catalog=new CatalogBean();
	private String pic;
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTiele() {
		return tiele;
	}
	public void setTiele(String tiele) {
		this.tiele = tiele;
	}
	public String getSpec() {
		return spec;
	}
	public void setSpec(String spec) {
		this.spec = spec;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public CatalogBean getCatalog() {
		return catalog;
	}
	public void setCatalog(CatalogBean catalog) {
		this.catalog = catalog;
	}

}
