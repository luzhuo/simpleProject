package com.lz.domain;

public class PageBean {

	private int pageNum;
	private int rowNum;
	private int MaxPage;
	private int rowPerPage = 16;
	
	
	public int getLastPage(){
		if(pageNum>1){
			return pageNum-1;
		}
		return 0;
	}
	public int getNextPage(){
		if(pageNum<MaxPage){
			return pageNum+1;
		}
		return MaxPage;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getMaxPage() {
		return MaxPage;
	}
	public void setMaxPage(int maxPage) {
		MaxPage = maxPage;
	}
	public int getRowPerPage() {
		return rowPerPage;
	}
	public void setRowPerPage(int rowPerPage) {
		this.rowPerPage = rowPerPage;
	}
	
	
}
