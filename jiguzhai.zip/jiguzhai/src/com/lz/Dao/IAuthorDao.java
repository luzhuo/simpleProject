package com.lz.Dao;

public interface IAuthorDao {

}
