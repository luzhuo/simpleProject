package com.lz.Dao;

import java.util.List;

import com.lz.entity.CatalogBean;

public interface ICatalogDao {

	public List<CatalogBean> getAllCatalogs() throws Exception ;
	public CatalogBean load(Long CatalogId) throws Exception;
}
