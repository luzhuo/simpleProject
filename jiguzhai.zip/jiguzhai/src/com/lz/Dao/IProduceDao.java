package com.lz.Dao;

import java.util.List;

import com.lz.domain.PageBean;
import com.lz.entity.ProduceBean;

public interface IProduceDao {
	public List<ProduceBean> getProduce(ProduceBean pb,PageBean pages)throws Exception;

}
