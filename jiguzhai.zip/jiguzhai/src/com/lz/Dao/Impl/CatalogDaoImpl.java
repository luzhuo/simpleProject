package com.lz.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lz.Dao.ICatalogDao;
import com.lz.entity.CatalogBean;
import com.lz.util.ConnectionMannage;

public class CatalogDaoImpl implements ICatalogDao{

	public List<CatalogBean> getAllCatalogs() throws Exception {
		List<CatalogBean> list = new ArrayList<>();
		Connection conn = null;
		try {
			conn = ConnectionMannage.getConnection();
			PreparedStatement ps = conn.prepareStatement("select * from t_catalog");
			ResultSet rs = ps.executeQuery();		
			while(rs.next()){
				CatalogBean temp = new CatalogBean();
				temp.setId(rs.getLong("id"));
				temp.setTitle(rs.getString("title"));
				list.add(temp);
			}
			for ( CatalogBean c : list) {
				System.out.println(c.getTitle()+c.getId());
			}
			rs.close();
			ps.close();
		} finally {
			ConnectionMannage.close(conn);
		}
		return list;
		
	}

	public CatalogBean load(Long catalogId) throws Exception {
		CatalogBean res = new CatalogBean();
		Connection conn = ConnectionMannage.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from t_catalog where id=?");
			ps.setLong(1,catalogId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				res.setId(rs.getLong("id"));
				res.setTitle(rs.getString("title"));
			}
			rs.close();ps.close();
		}finally{
			ConnectionMannage.close(conn);
		}
		
		
		
		return res;
	}

}
