package com.lz.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lz.Dao.IProduceDao;
import com.lz.domain.PageBean;
import com.lz.entity.ProduceBean;
import com.lz.util.ConnectionMannage;

public class ProduceDaoImpl implements IProduceDao {

	public List<ProduceBean> getProduce(ProduceBean pb, PageBean pages)
			throws Exception {
		Connection conn = null;
		conn = ConnectionMannage.getConnection();
		List<ProduceBean> res = new ArrayList<ProduceBean>();
		StringBuilder sql = new StringBuilder(
				"select p.*,c.title ctitle,a.name from t_produce p left join t_author a on a.id=p.author_id left join t_catalog c on c.id=p.catalog_id where 1=1 ");
		if (pb != null) {
			if (pb.getCatalog() != null && pb.getCatalog().getId() != null) {
				sql.append(" and c.id = ").append(pb.getCatalog().getId());
			}
			if (pb.getAuthor() != null) {
				sql.append(" and a.name like '").append(pb.getAuthor())
						.append("'");
			}
		}
		sql.append("order by p.click desc");
		ResultSet rs = null;
		PreparedStatement ps = null;
		if (pages != null & pages.getRowPerPage() > 1) {
			if (pages.getPageNum() < 1) {
				pages.setPageNum(1);
			}
			if (pages.getRowPerPage() > 1) {
				String pageSql = "Select count(*) "
						+ sql.substring(sql.indexOf(" from "));
				ps = conn.prepareStatement(pageSql);
				rs = ps.executeQuery();
				int page = 0;
				if (rs.next()) {
					page = rs.getInt(1);
				}
				if (page < 1) {
					return res;
				}
				int maxPage = page / pages.getRowPerPage();
				if (page % pages.getRowPerPage() != 0) {
					maxPage++;
				}
				pages.setMaxPage(maxPage);
				pages.setRowNum(page);
			}
			if (pages.getPageNum() > pages.getMaxPage()) {
				pages.setPageNum(pages.getMaxPage());
			}
			sql.insert(0, "select * from (select rownum rn,t.* from (");
			sql.append(") t where rownum<=")
					.append(pages.getRowPerPage() * pages.getPageNum())
					.append(") where rn>")
					.append((pages.getPageNum() - 1) * pages.getRowPerPage());
			/* ҳ��ֵ*ÿҳ���� (ҳ��ֵ-1)*ÿҳ����")"); */
		}

	System.out.println(sql.toString());
		ps = conn.prepareStatement(sql.toString());
		rs=ps.executeQuery();
		while (rs.next()) {
			ProduceBean p = new ProduceBean();
			p.setId(rs.getLong("id"));
			p.setPrice(rs.getDouble("price"));
			p.setTiele(rs.getString("title"));
			p.setSpec(rs.getString("spec"));
			p.setPic(rs.getString("pic"));
			p.setAuthor(rs.getString("name"));
			res.add(p);
		}
		conn.close();
		rs.close();
		ps.close();
		return res;
	}

}
