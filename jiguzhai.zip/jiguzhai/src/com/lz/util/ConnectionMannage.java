package com.lz.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionMannage {
	
	public static Connection getConnection() throws Exception{
		Class.forName("oracle.jdbc.OracleDriver");	
		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "lz", "123456");
	}
	public static void close(Connection conn) throws Exception{
		if(conn!=null){
			conn.close();
		}
	}
}
