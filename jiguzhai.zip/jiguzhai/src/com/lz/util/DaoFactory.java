package com.lz.util;

import com.lz.Dao.ICatalogDao;
import com.lz.Dao.IProduceDao;
import com.lz.Dao.Impl.CatalogDaoImpl;
import com.lz.Dao.Impl.ProduceDaoImpl;

public class DaoFactory {
	public static ICatalogDao getICatatlogDao(){
		return new CatalogDaoImpl();
	}
	public static IProduceDao getIPaoduceDao(){
		return new ProduceDaoImpl();
	}

}
