package com.lz.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Projections;

import com.lz.util.HibernateSessionFactory;

public abstract class BaseDaoImpl<T extends Serializable, ID extends Serializable>
		implements IBaseDao<T, ID> {
	private Class<T> persistClass;

	@SuppressWarnings("unchecked")
	public BaseDaoImpl() {
		persistClass = (Class<T>) (((ParameterizedType) getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0]);
	}

	public T save(T record) {
		Session session = HibernateSessionFactory.getSession();
		session.save(record);
		return record;
	}

	public T delete(T record) {
		Session session = HibernateSessionFactory.getSession();
		session.delete(record);
		return record;
	}

	@SuppressWarnings("unchecked")
	public T load(ID id) {
		Session session = HibernateSessionFactory.getSession();
		return (T) session.get(persistClass, id);
	}

	public T update(T record) {
		Session session = HibernateSessionFactory.getSession();
		session.update(record);
		return record;
	}

	@SuppressWarnings("unchecked")
	public List<T> selectByExample(T record, int... pages) {
		Session session = HibernateSessionFactory.getSession();
		Criteria c = session.createCriteria(persistClass);
		if (record != null)
			c.add(Example.create(record).enableLike());
		if (pages != null && pages.length > 0) {
			c.setFirstResult(pages[0]);
		}
		if (pages != null && pages.length > 1)
			c.setMaxResults(pages[1]);
		return c.list();
	}

	public int selectByExampleRowsNum(T record) {
		Session session = HibernateSessionFactory.getSession();
		Criteria c = session.createCriteria(persistClass);
		if (record != null)
			c.add(Example.create(record).enableLike());
		c.setProjection(Projections.rowCount());
		return ((Number) c.uniqueResult()).intValue();
	}

}
