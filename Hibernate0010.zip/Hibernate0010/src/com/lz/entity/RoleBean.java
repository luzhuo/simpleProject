package com.lz.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity(name="t_roles")
@SequenceGenerator(name="seq1",sequenceName="seq_roles",initialValue=1)
public class RoleBean {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private Long id;
	@Column(length=32 ,nullable=false ,unique=true)
	private String name;
	@Column(length=100)
	private String descn;
	@OneToMany(mappedBy="role" , cascade = CascadeType.ALL)
	private Set<UserBean> users = new HashSet<UserBean>();
	
	
	
	//===================================================
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescn() {
		return descn;
	}
	public void setDescn(String descn) {
		this.descn = descn;
	}
	public Set<UserBean> getUsers() {
		return users;
	}
	public void setUsers(Set<UserBean> users) {
		this.users = users;
	}
	
}
