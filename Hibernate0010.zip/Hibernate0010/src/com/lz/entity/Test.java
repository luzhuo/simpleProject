package com.lz.entity;

import org.hibernate.Session;

import com.lz.util.HibernateSessionFactory;

public class Test {
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		UserBean u = new UserBean();
		RoleBean role = new RoleBean();
		role.setName("111");
		u.setPassword("123");
		u.setUsername("222");
		
		u.setRole(role);
		role.getUsers().add(u);
		
		session.save(role);
		session.beginTransaction().commit();
		System.out.println("commit");
	}

}
