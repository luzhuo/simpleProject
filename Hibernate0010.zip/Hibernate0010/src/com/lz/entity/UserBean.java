package com.lz.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name = "t_users")
@org.hibernate.annotations.Entity(dynamicInsert=true)
@SequenceGenerator(name = "seq2", sequenceName = "seq_users")
public class UserBean {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq2")
	private Long id;
	@Column(length = 20, nullable = false, unique = true)
	private String username;
	@Column(length = 10, nullable = false)
	private String password;
	@Temporal(TemporalType.DATE)
	@Column(columnDefinition = "date default sysdate")
	private Date brith;
	@Column(columnDefinition = "number(1) default 1")
	private Boolean sex;
	@ManyToOne(optional = false)
	@JoinColumn(name = "role_id")
	private RoleBean role;
	@Column(precision = 6, scale = 2)
	private Double salary;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getBrith() {
		return brith;
	}

	public void setBrith(Date brith) {
		this.brith = brith;
	}

	public Boolean getSex() {
		return sex;
	}

	public void setSex(Boolean sex) {
		this.sex = sex;
	}

	public RoleBean getRole() {
		return role;
	}

	public void setRole(RoleBean role) {
		this.role = role;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

}
