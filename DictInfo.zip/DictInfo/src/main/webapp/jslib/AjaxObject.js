function AjaxObject() {
	this.xhr = null;
	this.createXHR = function() {
		if (window.ActiveXObject) {
			this.xhr = new ActiveXObject('Microsoft.XMLHttp');
		} else if (window.XMLHttpRequest) {
			this.xhr = new XMLHttpRequest();
		}
	};
	this.callback = function() {
	};
	this.sendRequest = function(url, params, HttpMethod) {
		if (!HttpMethod)
			HttpMethod = 'POST';
		this.createXHR();
		if (this.xhr) {
			this.xhr.open(HttpMethod, url, true);
			this.xhr.onreadystatechange = this.callback;
			if ('POST' == HttpMethod) {
				this.xhr.setRequestHeader("Content-Type",
						"application/x-www-form-urlencoded");
				this.xhr.send(params);
			} else
				this.xhr.send(null);
		} else {
			alert('您的浏览器不支持异步操作!');
		}
	};
}