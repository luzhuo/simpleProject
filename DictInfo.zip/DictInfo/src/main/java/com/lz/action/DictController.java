package com.lz.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lz.entity.DictBean;
import com.lz.serivce.DictService;
@Controller
@RequestMapping("/")
public class DictController {
	@Resource(name = "dictService")
	private DictService dictService;
	
	@RequestMapping(value = "province", method = RequestMethod.GET)
	@ResponseBody
	public List<DictBean> getProvince() throws Exception {
		return dictService.getAllProvinces();
	}
	@RequestMapping(value = "city", method = RequestMethod.GET)
	@ResponseBody
	public List<DictBean> getCitiesByProvince(@RequestParam Long id)throws Exception{
		System.out.println("province"+id);
		return dictService.getCitiesByPid(id);
	}
	@RequestMapping(value = "area", method = RequestMethod.GET)
	@ResponseBody
	public List<DictBean> getAreasByCity(@RequestParam Long id)throws Exception{
		System.out.println("city"+id);
		return dictService.getAreasByCid(id);
	}

}
