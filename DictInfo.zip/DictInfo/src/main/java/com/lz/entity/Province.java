package com.lz.entity;

public class Province extends DictBean {

	private static final long serialVersionUID = -3361412705730135091L;

}
