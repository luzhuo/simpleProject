package com.lz.entity;

public class Area extends DictBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7667813617621778981L;

}
