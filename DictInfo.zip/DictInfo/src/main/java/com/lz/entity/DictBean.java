package com.lz.entity;

import java.io.Serializable;

public class DictBean implements Serializable{

	private static final long serialVersionUID = -6264786784470674998L;

	private Long id;

    private String title;

    private Long parentId;

    private String descType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getDescType() {
        return descType;
    }

    public void setDescType(String descType) {
        this.descType = descType;
    }
}