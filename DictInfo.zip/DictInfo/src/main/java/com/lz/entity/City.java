package com.lz.entity;

public class City extends DictBean {

	private static final long serialVersionUID = 9011768214911254991L;

}
