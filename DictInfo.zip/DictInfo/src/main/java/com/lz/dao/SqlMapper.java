package com.lz.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface SqlMapper <T,ID extends Serializable>{

	 	int deleteByPrimaryKey(ID id);

	    int insertSelective(T record);

	    T selectByPrimaryKey(ID id);

	    int updateByPrimaryKeySelective(T record);

	    List<T> selectByMap(Map<String,Object> map);
	    
	    int selectByRowsNum(Map<String,Object> map);
}
