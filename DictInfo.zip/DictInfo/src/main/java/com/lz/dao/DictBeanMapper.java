package com.lz.dao;

import org.springframework.stereotype.Repository;

import com.lz.entity.DictBean;
@Repository("dictDao")
public interface DictBeanMapper extends SqlMapper<DictBean, Long>{
    
}