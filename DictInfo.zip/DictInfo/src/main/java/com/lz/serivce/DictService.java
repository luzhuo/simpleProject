package com.lz.serivce;

import java.util.List;

import com.lz.entity.DictBean;

public interface DictService {
	String PROVINCE_TYPE = "province";
	String CITY_TYPE = "city";
	String AREA_TYPE = "area";	

	public List<DictBean> getAllProvinces();

	public List<DictBean> getCitiesByPid(Long id);
	
	public List<DictBean> getAreasByCid(Long id);

}
