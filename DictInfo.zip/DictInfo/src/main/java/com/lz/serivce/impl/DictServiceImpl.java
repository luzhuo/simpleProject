package com.lz.serivce.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lz.dao.DictBeanMapper;
import com.lz.entity.DictBean;
import com.lz.serivce.DictService;
@Service("dictService")
@Transactional(readOnly=true,propagation=Propagation.SUPPORTS)
public class DictServiceImpl implements DictService {

	@Resource(name="dictDao")
	private DictBeanMapper dictMapper;
		


	@Override
	public List<DictBean> getCitiesByPid(Long id) {
		Map<String,Object> map= new HashMap<String,Object>();
		map.put("descType", CITY_TYPE);
		
		map.put("parentId", id);
		return dictMapper.selectByMap(map);
	}

	@Override
	public List<DictBean> getAreasByCid(Long id) {
		
		Map<String,Object> map= new HashMap<String,Object>();
		map.put("descType", AREA_TYPE);
		map.put("parentId", id);
		return dictMapper.selectByMap(map);
	}

	@Override
	public List<DictBean> getAllProvinces() {
		Map<String,Object> map= new HashMap<String,Object>();
		map.put("descType", PROVINCE_TYPE);
		return dictMapper.selectByMap(map);
	}


}
