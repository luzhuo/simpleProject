package com.lz.dao;

import com.lz.entity.ProduceBean;

public interface ProduceBeanMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ProduceBean record);

    int insertSelective(ProduceBean record);

    ProduceBean selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ProduceBean record);

    int updateByPrimaryKey(ProduceBean record);
}