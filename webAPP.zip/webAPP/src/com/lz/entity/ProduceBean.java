package com.lz.entity;

import java.math.BigDecimal;

public class ProduceBean {
    @Override
	public String toString() {
		return "ProduceBean [id=" + id + ", name=" + name + ", paddr=" + paddr
				+ ", price=" + price + "]";
	}

	private Long id;

    private String name;

    private String paddr;

    private BigDecimal price;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPaddr() {
        return paddr;
    }

    public void setPaddr(String paddr) {
        this.paddr = paddr;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}