package com.lz.test;

import com.lz.dao.ProduceBeanMapper;
import com.lz.entity.ProduceBean;

public class Test2 {
	private ProduceBeanMapper produceMapper;
	
	public void select(){		
		ProduceBean pb = produceMapper.selectByPrimaryKey(1L);
		System.out.println(pb.toString());
		
	}
	public static void main(String[] args) {
		
		
		
	}

}
