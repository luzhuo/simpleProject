package com.lz.domin;

import java.io.Serializable;

public class PageBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private int pageNum;
	private int rowsNum;//������
	private int maxPage;
	private int rowsPerPage = 15;//ÿҳ����
	private static int VIEW_PAGE = 7;
	public int getStartPage(){
		if(pageNum>VIEW_PAGE/2)
			return pageNum-VIEW_PAGE/2;	
		return 1;
	}
	public int getEndPage(){
		int res = getStartPage()+VIEW_PAGE-1;
		if(res<maxPage)
		return res;
		return maxPage;
	}
	public int getLastPage(){
		if(pageNum>1)
		return pageNum-1;
		return 1;
	}
	public int getNextPage(){
		if(pageNum<maxPage)
		return pageNum+1;
		return maxPage;
	}
	
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getRowsNum() {
		return rowsNum;
	}
	public void setRowsNum(int rowsNum) {
		this.rowsNum = rowsNum;
	}
	public int getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}
	public int getRowsPerPage() {
		return rowsPerPage;
	}
	public void RowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}
	

}
