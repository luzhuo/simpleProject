package com.lz.Test;


import java.math.BigDecimal;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.lz.dao.ProduceBeanMapper;
import com.lz.entity.ProduceBean;
import com.lz.filter.MybatisSessionFactory;

public class ProduceTest {
	private ProduceBeanMapper produceMapper;
	@Before
	public void setUp() throws Exception {
		
		MybatisSessionFactory.getSession();
		produceMapper = MybatisSessionFactory.getMapper(ProduceBeanMapper.class);
	}
	@Test
	public void testSelect() {
		ProduceBean pb = produceMapper.selectByPrimaryKey(1L);
		System.err.println(pb.toString());
	}
	@Test
	public void testUpdate() {
		
	}
	@Test
	public void testDelete() {
		
	}
	@Test
	public void testInsert() {
		ProduceBean p = new ProduceBean();
		p.setName("aaa");
		p.setId(4L);
		p.setPaddr("sss");
		p.setPrice(new BigDecimal(11.22));
		produceMapper.insert(p);
	}
//	@Test
//	public void testDynamicSQL() {
//		ProduceBean produce = null;
//		StringBuilder sb1 = new StringBuilder("insert into t_produce(name");
//		StringBuilder sb2 = new StringBuilder(") values(?");
//		if(produce!=null){
//			if(produce.getId()!=null){
//				sb1.append(",id");
//				sb2.append(",?");
//			}
//		}
//	}
	

	@After
	public void tearDown() throws Exception {
		MybatisSessionFactory.commitTransaction();	
		MybatisSessionFactory.closeSession();
	}



}
