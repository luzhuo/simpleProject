create table t_roles(
 id number(18) primary key,
 name varchar2(32 char) not null,
 nemo varchar2(200 char)
);
create sequence seq_roles start with 1 maxvalue 999999999;

create or replace trigger tri_roles_id
	before insert or update of id on t_roles
	for each row
begin
	if inserting then
		select seq_roles.nextval into :new.id from dual;
	elsif updating then
		raise_application_error(-20001,'id�������޸�');
	end if;
end ;

insert into t_roles(name) values('系统管理员');
insert into t_roles(name) values('一般管理员');
insert into t_roles(name) values('其他管理员');

create table t_users(
 id number(18) primary key,
 username varchar2(32 char) not null unique,
 password varchar2(32 char) not null,
 birth date default sysdate,
 sex number(1) default 1,
 role_id number(18) not null,
 foreign key(role_id) references t_roles(id) on delete cascade
);
create sequence seq_users start with 1 maxvalue 999999999;

create or replace trigger tri_users_id
	before insert or update of id on t_users
	for each row
begin
	if inserting then
		select seq_users.nextval into :new.id from dual;
	elsif updating then
		raise_application_error(-20001,'id�������޸�');
	end if;
end ;

insert into t_users(username,password,role_id) values('luzhuo','111',1)








 <sql id="condition">
 <where>
 <if test="id!=null">
 	id=#{id,jdbcType=DECIMAL}
 </if>
 </where>
 </sql>
 <select id="selectByMap" parameterType="map" resultMap="BaseResultMap">
 	<if test="pageNum!=null and rowsPerPage!=null and rowsPerPage>0">
 	select * from(
 		select t.*,rownum rn from(
 	</if>
 	select <include refid="Base_Column_List"/> from t_roles <include refid="condition"/>
 	<if test="pageNum!=null and rowsPerPage!=null and rowsPerPage>0">
 	<![CDATA[
 	)t where rownum<=${pageNum*rowsPerPage}
 	)where rn>${(pageNum-1)*rowsPerPage}
 	]]>
 	</if>
 </select>
 <select id="selectByMapRowsNum" parameterType="map" resultType="int">
 	select count(id) from t_roles
 	<include refid="condition"></include>
 </select>