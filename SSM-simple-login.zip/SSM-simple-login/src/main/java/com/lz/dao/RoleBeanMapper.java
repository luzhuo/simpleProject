package com.lz.dao;

import org.springframework.stereotype.Repository;

import com.lz.entity.RoleBean;
@Repository("roleDao")
public interface RoleBeanMapper extends SqlMapper<RoleBean, Long>{
   
}