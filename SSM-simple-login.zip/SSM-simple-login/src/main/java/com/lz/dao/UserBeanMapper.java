package com.lz.dao;

import org.springframework.stereotype.Repository;

import com.lz.entity.UserBean;
@Repository("userDao")
public interface UserBeanMapper extends SqlMapper<UserBean,Long>{
  
}