package com.lz.action;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lz.entity.RoleBean;
import com.lz.entity.UserBean;
import com.lz.service.UserService;
import com.lz.validator.groups.AddGroup;
import com.lz.validator.groups.LoginGroup;

@Controller
@RequestMapping("/")
public class UserController {
	
	@Resource(name="userService")
	private UserService userService;
//自定义效验器
//	@Resource(name="userValidator")
//	private UserValidator uv;
	@RequestMapping(value="regist",method=RequestMethod.GET)
	public String regist(Model model)throws Exception{
		
		return "user/regist";
	}
	@RequestMapping(value="regist",method=RequestMethod.POST)
	public String regist(@ModelAttribute("user")@Validated(AddGroup.class) UserBean user,
			Errors errors,HttpSession session)throws Exception{
		
		if(StringUtils.isNotBlank(user.getRepassword())){
			if(!user.getPassword().equals(user.getRepassword())){
				errors.rejectValue("repassword",null, "与第一次口令不一致");
			}
		}
		if(errors.hasErrors()){
			return "user/regist";
		}else{
		return "user/login";
		}
	}
	
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String login(Model model)throws Exception{
		return "user/login";
	}
	@RequestMapping(value="login",method=RequestMethod.POST)
	public String login(@ModelAttribute("user")@Validated(LoginGroup.class) UserBean user,Errors errors,HttpSession session)throws Exception{
		

		Object object = session.getAttribute("checkcode");
			if(!user.getCheckcode().equals(object)){
				errors.rejectValue("checkcode", null,"验证码错误");
			}
	
			if(errors.hasErrors()){
				return "user/login";
			}
			boolean bb = userService.login(user);
			if(bb){
				errors.rejectValue("password", null,"password error!");
				return "redirect:/user/list.do";
			}else{
				return "user/login";
			}
			
	}
	@ModelAttribute("user")
	public UserBean user(){
		return new UserBean();
	}
	@ModelAttribute("sexOptions")
	public Map<Boolean,String> sexOptions(){
		Map<Boolean,String> map = new LinkedHashMap<Boolean,String>();
		map.put(true, "男");
		map.put(false, "女");
		return map;
	}
	
	@ModelAttribute("roleList")
	public List<RoleBean> roleList(){
		return userService.getAllRoles();
	}
}
