package com.lz.entity;

public class RoleBean extends BaseBean<Long>{

	private static final long serialVersionUID = -1302491623327134245L;

	private String name;

    private String nemo;



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNemo() {
        return nemo;
    }

    public void setNemo(String nemo) {
        this.nemo = nemo;
    }
}