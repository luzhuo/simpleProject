package com.lz.entity;

import java.util.Date;

import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.lz.validator.groups.AddFirstGroup;
import com.lz.validator.groups.AddSecondGroup;
import com.lz.validator.groups.AddThirdGroup;
import com.lz.validator.groups.LoginFirstGroup;
import com.lz.validator.groups.LoginSecondGroup;
import com.lz.validator.groups.LoginThirdGroup;

public class UserBean extends BaseBean<Long>{

	private static final long serialVersionUID = 343608933582369802L;
	@NotBlank(message="用户名称不能为空",groups={LoginFirstGroup.class,AddFirstGroup.class})
	@Length(min=6,max=20,message="用户名称6-20之间",groups={LoginSecondGroup.class,AddSecondGroup.class})
	@Pattern(regexp="^[a-zA-Z0-9]{6,20}$",message="用户名称不合法",groups={LoginThirdGroup.class,AddThirdGroup.class})
	private String username;
	@NotBlank(message="用户口令不能为空",groups={LoginFirstGroup.class,AddFirstGroup.class})
	@Length(min=6,max=20,message="用户口令6-20之间",groups={LoginSecondGroup.class,AddSecondGroup.class})
    private String password;
	@NotBlank(message="必须指定生日",groups={AddFirstGroup.class})
	@Past(message="穿越？",groups={AddSecondGroup.class})
    private Date birth;
    @NotBlank(message="必须指定性别",groups={AddFirstGroup.class})
    private boolean sex;
    @NotBlank(message="必须指定身份",groups={AddFirstGroup.class})
    private Long roleId;
    
    private RoleBean role = new RoleBean();
    @NotBlank(message="验证码不能为空",groups={LoginFirstGroup.class})
    private String checkcode;
    @NotBlank(message="确认口令不能为空",groups={AddFirstGroup.class})
	@Length(min=6,max=20,message="确认口令6-20之间",groups={AddSecondGroup.class})
    private String repassword;
    
    public String getRepassword() {
		return repassword;
	}

	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}

	public String getCheckcode() {
		return checkcode;
	}

	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}

	public RoleBean getRole() {
		return role;
	}

	public void setRole(RoleBean role) {
		this.role = role;
	}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public boolean getSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }
}