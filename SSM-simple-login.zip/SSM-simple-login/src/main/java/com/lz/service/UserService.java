package com.lz.service;

import java.util.List;

import com.lz.entity.RoleBean;
import com.lz.entity.UserBean;

public interface UserService {

	boolean login(UserBean user);
	List<RoleBean> getAllRoles();

}
