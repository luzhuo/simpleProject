package com.lz.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.lz.dao.RoleBeanMapper;
import com.lz.dao.UserBeanMapper;
import com.lz.entity.RoleBean;
import com.lz.entity.UserBean;
import com.lz.service.UserService;

@Service("userService")
@Transactional(readOnly=true,propagation=Propagation.SUPPORTS)
public class UserServiceImpl implements UserService{
	@Resource(name="userDao")
	private UserBeanMapper userMapper;

	@Resource(name="roleDao")
	private RoleBeanMapper roleMapper;
	@Override
	public boolean login(UserBean user) {
		boolean bb=false;
		Assert.notNull(user,"参数错误");
		Assert.hasText(user.getUsername(),"用户名错误");
		Assert.hasText(user.getPassword(),"用户口令错误");
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("username", user.getUsername());
		map.put("password", user.getPassword());	
		List<UserBean> ulist = userMapper.selectByMap(map);
		if(ulist!=null && ulist.size()>0){
			UserBean temp = ulist.get(0);
			BeanUtils.copyProperties(temp, user);
			bb=true;
		}
		return bb;
	}

	@Override
	public List<RoleBean> getAllRoles() {
		
		return roleMapper.selectByMap(null);
	}
}
