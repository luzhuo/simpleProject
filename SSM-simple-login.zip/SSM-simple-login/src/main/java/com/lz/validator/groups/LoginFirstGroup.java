package com.lz.validator.groups;

public interface LoginFirstGroup {

}
