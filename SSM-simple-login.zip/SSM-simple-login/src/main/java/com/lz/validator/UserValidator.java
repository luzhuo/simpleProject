package com.lz.validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.lz.entity.UserBean;
@Component("userValidator")
public class UserValidator implements Validator {

	private String method;
	@Override
	public boolean supports(Class<?> arg0) {
		
		return UserBean.class==arg0;
	}

	@Override
	public void validate(Object arg0, Errors errors) {
		UserBean user=(UserBean)arg0;
		if("login".equals(method)){
			if(StringUtils.isBlank(user.getUsername())){
				errors.rejectValue("username", null,"用户名称不能为空");
			}
			if(StringUtils.isBlank(user.getPassword())){
				errors.rejectValue("password", null,"用户口令不能为空");
			}
		}
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	
}
