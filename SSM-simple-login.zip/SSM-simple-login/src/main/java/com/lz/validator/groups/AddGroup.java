package com.lz.validator.groups;

import javax.validation.GroupSequence;

@GroupSequence({AddFirstGroup.class,AddSecondGroup.class,AddThirdGroup.class})
public class AddGroup {

}
