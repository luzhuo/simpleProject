package com.lz.validator.groups;

public class AddSecondGroup {

}
