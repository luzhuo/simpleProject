package com.lz.validator.groups;

import javax.validation.GroupSequence;

@GroupSequence({LoginFirstGroup.class,LoginSecondGroup.class,LoginThirdGroup.class})
public interface LoginGroup {
	
}
