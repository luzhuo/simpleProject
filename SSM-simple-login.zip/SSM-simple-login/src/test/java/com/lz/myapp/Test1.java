package com.lz.myapp;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lz.entity.UserBean;
import com.lz.service.UserService;

public class Test1 {
	public static void main(String[] args) throws SQLException {
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserService bean = ac.getBean("userService",UserService.class);
		UserBean user = new UserBean();
		user.setUsername("luzhuo");
		user.setPassword("111");
		System.out.println(bean.login(user));
	}

}
