package com.lz.biz.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.lz.biz.StudentDao;
import com.lz.dao.StudentBeanMapper;
import com.lz.entity.StudentBean;
import com.lz.util.MybatisSessionFactory;

public class StudentDaoImpl implements StudentDao{

	@Override
	public List<StudentBean> selectAll() throws Exception {
		SqlSession session  = MybatisSessionFactory.getSession();
		StudentBeanMapper mapper = session.getMapper(StudentBeanMapper.class);
		List<StudentBean> list = mapper.selectAll(null);
		MybatisSessionFactory.closeSession();
		return list;
	}

	@Override
	public StudentBean select(String mark) throws Exception {
		SqlSession session  = MybatisSessionFactory.getSession();
		StudentBeanMapper mapper = session.getMapper(StudentBeanMapper.class);
		StudentBean student = mapper.select(mark);
		MybatisSessionFactory.closeSession();
		return student;
	}

	@Override
	public boolean add(StudentBean student) throws Exception {
		SqlSession session  = MybatisSessionFactory.getSession();
		StudentBeanMapper mapper = session.getMapper(StudentBeanMapper.class);
		int insert = mapper.insert(student);
		if(insert==1){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public boolean update(StudentBean student) throws Exception {
		SqlSession session  = MybatisSessionFactory.getSession();
		StudentBeanMapper mapper = session.getMapper(StudentBeanMapper.class);
		int update = mapper.update(student);
		if(update==1){
			return true;
		}else{
			return false;
		}
	}

}
