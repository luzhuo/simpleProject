package com.lz.biz;

import java.util.List;

import com.lz.entity.StudentBean;

public interface StudentDao {
	public List<StudentBean> selectAll() throws Exception;
	public StudentBean select(String mark) throws Exception;
	public boolean add(StudentBean student) throws Exception;
	public boolean update(StudentBean student) throws Exception;
}
