package com.lz.test;

import java.util.List;

import com.lz.biz.StudentDao;
import com.lz.entity.StudentBean;
import com.lz.util.FactoryUtil;

public class Test {
	public static void main(String[] args) throws Exception {
		StudentDao s = FactoryUtil.getStudentUtil();
		List<StudentBean> list = s.selectAll();
		for (StudentBean st : list) {
			System.out.println(st);
		}
	}
}
