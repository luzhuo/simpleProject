package com.lz.util;

import com.lz.biz.StudentDao;
import com.lz.biz.impl.StudentDaoImpl;

public class FactoryUtil {
	public static StudentDao getStudentUtil(){
		return new StudentDaoImpl();
	}

}
