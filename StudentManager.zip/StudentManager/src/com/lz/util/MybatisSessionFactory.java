package com.lz.util;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisSessionFactory {

	private MybatisSessionFactory(){
		
	}
	
	static{		
		getFactory();
	}
	
	private static ThreadLocal<SqlSession> ts = new ThreadLocal<SqlSession>();
	private static SqlSessionFactory factory;
	//bulidFactory
	private static void buildFactory(){
		if(factory==null){
			try {
				Reader r = Resources.getResourceAsReader("mybaties-config.xml");
				factory = new SqlSessionFactoryBuilder().build(r);
			} catch (IOException e) {			
				e.printStackTrace();
			}
		}
	}
	
	public static <T>T getMapper(Class<T> clz){
		SqlSession ss = getSession();
		if (ss != null)
			return ss.getMapper(clz);
		return null;

	}
	
	public static SqlSessionFactory getFactory(){
		buildFactory();
		return factory;
	}
	public static SqlSession getSession(){
		SqlSession ss= ts.get();
		if(ss==null){
			ss=factory!=null?factory.openSession():null;
			ts.set(ss);
		}
		return ss;
	}
	public static void closeSession(){
		SqlSession ss = ts.get();
		ts.set(null);
		if(ss!=null)
			ss.close();
	}
	
	public static void commitTransaction(){
		SqlSession ss = getSession();
		if(ss!=null)
			ss.commit();
	}
	
	public static void rollbackTransaction(){
		SqlSession ss = getSession();
		if(ss!=null)
			ss.rollback();
	}

}
