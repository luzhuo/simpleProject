package com.lz.entity;

public class StudentBean {
    @Override
	public String toString() {
		return "StudentBean [id=" + id + ", mark=" + mark + ", age=" + age
				+ ", idCard=" + idCard + ", address=" + address + ", name="
				+ name + ", password=" + password + ", grade=" + grade
				+ ", school=" + school + ", info=" + info + "]";
	}

	private Long id;

    private String mark;

    private String age;

    private String idCard;

    private String address;

    private String name;

    private String password;

    private String grade;

    private String school;

    private String info;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}