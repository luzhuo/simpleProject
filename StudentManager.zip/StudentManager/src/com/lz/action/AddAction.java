package com.lz.action;

import com.lz.biz.StudentDao;
import com.lz.entity.StudentBean;
import com.lz.util.FactoryUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class AddAction extends ActionSupport implements ModelDriven<StudentBean> {

	private static final long serialVersionUID = 6552813245309523944L;
	private StudentBean student = new StudentBean();
	public void validate(){
		if(student.getName()==null||student.getName().trim().length()<1){
			this.addFieldError("name", "用户名不能为空");
		}
		if(student.getPassword()==null||student.getPassword().trim().length()<1){
			this.addFieldError("password", "用户密码不能为空");
		}
		if(student.getAddress()==null||student.getAddress().trim().length()<1){
			this.addFieldError("address", "用户密码不能为空");
		}
		if(student.getAge()==null||student.getAge().trim().length()<1){
			this.addFieldError("age", "用户密码不能为空");
		}
		if(student.getGrade()==null||student.getGrade().trim().length()<1){
			this.addFieldError("grade", "用户密码不能为空");
		}
		if(student.getIdCard()==null||student.getIdCard().trim().length()<1){
			this.addFieldError("idCard", "用户密码不能为空");
		}
		if(student.getSchool()==null||student.getSchool().trim().length()<1){
			this.addFieldError("school", "用户密码不能为空");
		}
		if(student.getMark()==null||student.getMark().trim().length()<1){
			this.addFieldError("mark", "用户密码不能为空");
		}		
	}
	@Override
	public String execute() throws Exception {
		StudentDao util = FactoryUtil.getStudentUtil();
		boolean bb = util.add(student);
		if(bb){
			this.addActionError("添加成功");
		return SUCCESS;
		}else{			
			return INPUT;
		}
	}
	@Override
	public StudentBean getModel() {		
		return student;
	}

}
