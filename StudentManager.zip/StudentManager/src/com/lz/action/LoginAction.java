package com.lz.action;

import java.util.List;
import java.util.Map;

import com.lz.biz.StudentDao;
import com.lz.entity.StudentBean;
import com.lz.util.FactoryUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;



public class LoginAction extends ActionSupport implements ModelDriven<StudentBean> {

	private static final long serialVersionUID = 297036793219129203L;
	private StudentBean student = new StudentBean();	
	private ActionContext ac = ActionContext.getContext();
	public void validate(){
		
		if(student.getPassword()==null||student.getPassword().trim().length()<1){
			this.addFieldError("password", "用户密码不能为空");
		}
		
		if(student.getMark()==null||student.getMark().trim().length()<1){
			this.addFieldError("mark", "用户学号不能为空");
		}		
	}
	@Override
	public String execute() throws Exception {
		StudentDao s = FactoryUtil.getStudentUtil();
		StudentBean st = null;
		String password = null;
		try {
			 st= s.select(student.getMark());
			 password = st.getPassword();
		} catch (Exception e) {
			password =null;
			this.addFieldError("mark", "用户名不存在");
			return INPUT;
		}
		String inputPassword = student.getPassword();
		if(inputPassword.equals(password)){				
			Map<String, Object> session = ac.getSession();
			Map<String, Object> application = ac.getApplication();
			List<StudentBean> list = s.selectAll();
			application.put("alluser", st);
			session.put("list", list);
			session.put("student", st);
			return SUCCESS;
		}else{
			this.addActionError("用户名或者密码错误");
			return INPUT;
		}
		
	}
	@Override
	public StudentBean getModel() {	
		return student;
	}
	
}
