package com.lz.dao;

import java.util.List;
import java.util.Map;

import com.lz.entity.StudentBean;

public interface StudentBeanMapper {
    int deleteByPrimaryKey(String idCart);

    int insert(StudentBean record);

    int insertSelective(StudentBean record);
    
    StudentBean select(String mark);
    
    List<StudentBean> selectAll(Map<String,Object> map);

    int update(StudentBean record);

}