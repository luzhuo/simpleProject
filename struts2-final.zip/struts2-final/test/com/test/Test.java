package com.test;

import java.util.List;

import com.lz.biz.IAccountServ;
import com.lz.domin.PageBean;
import com.lz.entity.AccountBean;
import com.lz.entity.UserBean;
import com.lz.util.FactorySer;

public class Test {
public static void main(String[] args) {
	IAccountServ accountUtil = FactorySer.getAccountUtil();
	PageBean pages = null;
	UserBean user = null;
	user.setId(2L);
	try {
		List<AccountBean> ssss = accountUtil.getMonthAndPage(user, pages);
		for (AccountBean a : ssss) {
			System.out.println("222"+a);
		}
	} catch (Exception e) {
		System.out.println("Ϲ���ѱ���");
		e.printStackTrace();
	}
}
}
