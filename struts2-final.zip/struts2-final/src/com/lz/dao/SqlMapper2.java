package com.lz.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface SqlMapper2<T,ID extends Serializable> {
	int deleteByPrimaryKey(ID id);

	int insertSelective(T record);

	T selectByPrimaryKey(ID id);

	int updateByPrimaryKeySelective(T record);

	int selectByMapRowsNum(Map<String, Object> map);

	List<T> selectByMap(Map<String, Object> map);


}
