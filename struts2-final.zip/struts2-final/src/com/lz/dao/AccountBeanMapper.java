package com.lz.dao;

import com.lz.entity.AccountBean;

public interface AccountBeanMapper extends SqlMapper2<AccountBean, Integer>{
    
}