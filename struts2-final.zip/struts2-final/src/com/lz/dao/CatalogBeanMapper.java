package com.lz.dao;

import com.lz.entity.CatalogBean;

public interface CatalogBeanMapper extends SqlMapper2<CatalogBean, Integer>{
   
}