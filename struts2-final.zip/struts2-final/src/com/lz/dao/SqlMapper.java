package com.lz.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface SqlMapper<T,ID extends Serializable> {

	int deleteByPrimaryKey(ID id);

    int insertSelective(T record);

    int updateByPrimaryKeySelective(T record);
    
    List<T> selectAll(Map<String ,Object> map);
    
    int getRows();
    
    T select(String username);

}
