package com.lz.interceptor;

import java.util.Map;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class CheckLoginInterceptor extends AbstractInterceptor{
	private static final long serialVersionUID = 4416527382423426428L;

	@Override
	public String intercept(ActionInvocation arg0) throws Exception {
		ActionContext ac = arg0.getInvocationContext();
		if(ac!=null){
			Map<String,Object> map =ac.getSession();//��ȡ���е�attribute
			if(map!=null){			
				if(map.containsKey("user")){
					return arg0.invoke();//��������ִ��
				}
			}
		}
		return Action.LOGIN;
	}

}
