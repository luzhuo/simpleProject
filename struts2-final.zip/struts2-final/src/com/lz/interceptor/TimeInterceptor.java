package com.lz.interceptor;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionProxy;
import com.opensymphony.xwork2.Result;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import com.opensymphony.xwork2.interceptor.PreResultListener;

public class TimeInterceptor extends MethodFilterInterceptor {

	private static final long serialVersionUID = 2394212269406033885L;

	@Override
	protected String doIntercept(ActionInvocation arg0) throws Exception {
		long start = System.currentTimeMillis();
		String url = ServletActionContext.getRequest().getRequestURI().toString();
		
		arg0.addPreResultListener(new PreResultListener(){ 		
			@Override
			public void beforeResult(ActionInvocation arg0, String arg1) {
				// TODO Auto-generated method stub
				
			}
		});
			
		
//		System.out.println("���ص�ַ"+url);
//		Object action = arg0.getAction();
//		System.out.println(action);
//		ActionProxy proxy = arg0.getProxy();
//		System.out.println(proxy);
//		Result result = arg0.getResult();
//		System.out.println(result);
		String invoke = arg0.invoke();//success or false
		long end = System.currentTimeMillis();
		System.out.println("ִ�У�"+url+"����ʱ��Ϊ"+(end-start)+"ms");
		return invoke;
	}
	
}
