package com.lz.entity;

import java.math.BigDecimal;
import java.util.Date;

public class AccountBean extends BaseBean<Long>{

	private static final long serialVersionUID = -1304140517385634258L;

	private Boolean payment;

    private Date adate;

    private Long catalogId;
    private CatalogBean catalog = new CatalogBean();

    public CatalogBean getCatalog() {
		return catalog;
	}

	public void setCatalog(CatalogBean catalog) {
		this.catalog = catalog;
	}

	private BigDecimal money;

    private String remark;

    private Long userId;

    public Boolean getPayment() {
        return payment;
    }

    public void setPayment(Boolean payment) {
        this.payment = payment;
    }

    public Date getAdate() {
        return adate;
    }

    public void setAdate(Date adate) {
        this.adate = adate;
    }

    public Long getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(Long catalogId) {
        this.catalogId = catalogId;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}