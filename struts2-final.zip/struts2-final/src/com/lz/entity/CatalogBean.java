package com.lz.entity;

public class CatalogBean  extends BaseBean<Long>{

	private static final long serialVersionUID = 629231671222522254L;

	private String title;

    private Short descn;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Short getDescn() {
        return descn;
    }

    public void setDescn(Short descn) {
        this.descn = descn;
    }
}