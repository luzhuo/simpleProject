package com.lz.util;

import com.lz.biz.AccountImpl;
import com.lz.biz.IAccountServ;
import com.lz.biz.IUserServ;
import com.lz.biz.UserImpl;

public class FactorySer {

	public static IUserServ getUserUtil(){
		return new UserImpl();
	}
	public static IAccountServ getAccountUtil(){
		return new AccountImpl();
	}
}
