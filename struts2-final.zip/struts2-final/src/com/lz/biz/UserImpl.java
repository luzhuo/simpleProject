package com.lz.biz;

import com.lz.dao.UserBeanMapper;
import com.lz.entity.UserBean;
import com.lz.util.MybatisSessionFactory;

public class UserImpl implements IUserServ{

	@Override
	public UserBean login(UserBean user) throws Exception {
		UserBeanMapper mapper = MybatisSessionFactory.getMapper(UserBeanMapper.class);
			String username = user.getUsername();
			UserBean check = mapper.select(username);		
		return check;
	}



}
