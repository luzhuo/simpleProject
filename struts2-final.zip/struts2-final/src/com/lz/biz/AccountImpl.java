package com.lz.biz;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lz.dao.AccountBeanMapper;
import com.lz.domin.PageBean;
import com.lz.entity.AccountBean;
import com.lz.entity.UserBean;
import com.lz.util.MybatisSessionFactory;

public class AccountImpl implements IAccountServ{

	@Override
	public List<AccountBean> getMonthAndPage(UserBean user, PageBean pages)
			throws Exception {
		AccountBeanMapper mapper = MybatisSessionFactory.getMapper(AccountBeanMapper.class);
		Map<String,Object> map = new HashMap<String ,Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM");
		Date now = new Date();
		String ss= df.format(now);
		map.put("now", ss);
		map.put("order", "adate desc");
		map.put("userId", user.getId());

		if(pages!=null&&pages.getPageNum()>0){
			if(pages.getPageNum()<1){
				pages.setPageNum(1);
			}
			if(pages.getMaxPage()<1){
				int rows= mapper.selectByMapRowsNum(map);
				if(rows<1){
					return null;
				}
				int max = (rows-1+pages.getRowsPerPage())/pages.getRowsPerPage();
				pages.setRowsNum(rows);
				pages.setMaxPage(max);
			}
				if(pages.getPageNum()>pages.getMaxPage())
					pages.setPageNum(pages.getMaxPage());
		}		
		map.put("pageNum", pages.getPageNum());
		map.put("rowsPerPage",pages.getRowsPerPage());
		return mapper.selectByMap(map);
	}
}

