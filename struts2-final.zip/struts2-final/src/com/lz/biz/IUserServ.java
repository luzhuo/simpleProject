package com.lz.biz;

import com.lz.entity.UserBean;

public interface IUserServ {
	public UserBean login(UserBean user) throws Exception;

}
