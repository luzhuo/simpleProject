package com.lz.biz;

import java.util.List;

import com.lz.domin.PageBean;
import com.lz.entity.AccountBean;
import com.lz.entity.UserBean;

public interface IAccountServ {

	List<AccountBean> getMonthAndPage(UserBean user, PageBean pages) throws Exception;

}
