package com.lz.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.SessionAware;

import com.lz.biz.IAccountServ;
import com.lz.domin.PageBean;
import com.lz.entity.AccountBean;
import com.lz.entity.UserBean;
import com.lz.util.FactorySer;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
@Namespace("/money")
@ParentPackage("admin")
public class MoneyAction extends ActionSupport implements SessionAware{

	private static final long serialVersionUID = 51284025698688487L;
	private IAccountServ ias =  FactorySer.getAccountUtil();
	private PageBean pages = new PageBean();
	private int rowsPerPage = 2;
	private Map<String,Object> sessionAttr;
	@Action(value="list",params={"rowsPerPage","2"},results = {
			@Result(name="success",location="/WEB-INF/content/money/list.jsp")
	})
	public String list(){
		pages.setRowsPerPage(rowsPerPage);
		UserBean user = (UserBean)sessionAttr.get("user");
		List<AccountBean> alist;
		try {
			alist = ias.getMonthAndPage(user,pages);	
			ActionContext.getContext().put("accountList", alist);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}
	@Override
	public void setSession(Map<String, Object> arg0) {
		this.sessionAttr = arg0;
		
	}
	//=====
	public PageBean getPages() {
		return pages;
	}
	public void setPages(PageBean pages) {
		this.pages = pages;
	}
	public int getRowsPerPage() {
		return rowsPerPage;
	}
	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}
	
}
