package com.lz.action;

import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.SessionAware;

import com.lz.biz.IUserServ;
import com.lz.entity.UserBean;
import com.lz.util.FactorySer;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
@Namespace("/")
@ParentPackage("fronter")
public class UserAction extends ActionSupport implements ModelDriven<UserBean>,SessionAware{

	private static final long serialVersionUID = -2235261660053925727L;
	private UserBean user = new UserBean();
	private IUserServ userv = FactorySer.getUserUtil();
	private Map<String,Object> session;
	@Action(value="login",results = {
			@Result(name="success",type="redirectAction",params={"actionName","list","namespace","/money"}), 
			@Result(name="input" ,location="/index.jsp")
	})
	public String login(){
		boolean bb = false;
		String password = user.getPassword();
		try {
				UserBean check = userv.login(user);
				bb = check.getPassword().equals(password);
			if(bb){		
				session.put("user", check);
				return SUCCESS;
			}else{
				this.addActionError("�û��������������");
				return INPUT;
			}
		} catch (Exception e) {
			this.addActionError("�û���������");
			e.printStackTrace();
		}
		return INPUT;
	}
	@Action(value="regist",interceptorRefs={
			@InterceptorRef("token"),@InterceptorRef("defaultStack")			
	},results = {
			@Result(name="success",location="/regist.jsp"), 
			@Result(name="input" ,location="/regist.jsp"),
			@Result(name="invalid.token",location="/err.jsp",type="redirect")
	})
	public String add() throws Exception{
		System.out.println(user);
		return INPUT;
	}
	@Override
	public UserBean getModel() {
		// TODO Auto-generated method stub
		return user;
	}

	@Override
	public void setSession(Map<String, Object> arg0) {
		session=arg0;
		
	}
}
