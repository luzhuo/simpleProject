
function print(adress) {
	window.open(adress, 'popUpWin', 'toolbar=no,location=no,directories=yes,status=no,menubar=yes,scrollbar=yes,resizable=yes,copyhistory=yes');
}