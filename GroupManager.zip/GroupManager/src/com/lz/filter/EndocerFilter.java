package com.lz.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.lz.util.StringUtil;

public class EndocerFilter implements Filter {
	private String encoding = "GBK";
	public void destroy() {
	
	}
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		arg0.setCharacterEncoding(encoding);
		arg2.doFilter(arg0, arg1);
	}
	public void init(FilterConfig arg0) throws ServletException {
		String ss = arg0.getInitParameter("encoding");
		if(StringUtil.isBlank(ss))
			encoding=ss.trim();
	}

}
