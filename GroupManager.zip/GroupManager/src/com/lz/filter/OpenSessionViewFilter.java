package com.lz.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.lz.util.MybatisSessionFactory;

public class OpenSessionViewFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
			try {
				MybatisSessionFactory.getSession();
				arg2.doFilter(arg0, arg1);//��������ִ��
				MybatisSessionFactory.commitTransaction();
			} catch (Exception e) {
				MybatisSessionFactory.rollbackTransaction();
				e.printStackTrace();
			}finally{
				MybatisSessionFactory.closeSession();
			}

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
