package com.lz.test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import com.lz.domin.PageBean;
import com.lz.entity.ListBean;
import com.lz.entity.ManagerBean;
import com.lz.entity.PowerBean;
import com.lz.entity.ShopperBean;
import com.lz.entity.ShoppingBean;
import com.lz.util.DBUtil;
import com.lz.util.ListUtil;
import com.lz.util.ManagerUtil;
import com.lz.util.PowerUtil;
import com.lz.util.ShopperUtil;

public class Test {
	public static void main(String[] args){
			
//		List<ManagerBean> all = ManagerUtil.selectAll(null);
//		for (ManagerBean m : all) {
//			System.out.println(m.getPower_name().getPower().getUrl());
//		}
//		List<PowerBean> list = PowerUtil.selectAll(null);
//		for (PowerBean p : list) {
//			System.out.println(p.getName());
//		}
//		List<ManagerBean> list = ManagerUtil.selectAll(null);
//		for (ManagerBean m : list) {
//			System.out.println(m.toString());
//		}
//		PowerBean look = PowerUtil.look(1L);
//		System.out.println(look.getName());
//		ListBean look = ListUtil.look(1L);
//		System.out.println(look.toString());
		


		
		
//		ShoppingBean s = new ShoppingBean();
//		s.setAddress("��Ϊ");
//		s.setGoods("p10");
//		s.setId(9L);
//		s.setPrice(1239.99);
		
//		PageBean page = new PageBean();
		//page.setPageNum(1);
//		DBUtil.delete(7L);
//		DBUtil.add(s);
//		for (Long i = 1L; i <= 7L; i++) {
//			DBUtil.look(i);
//		}
//		DBUtil.update(s);
//		List<ShoppingBean> list = DBUtil.selectAll(page);
//		for (ShoppingBean s : list) {
//			System.out.println(s);
//		}
//		ShopperBean shop = new ShopperBean();
//		shop.setId(2L);
//		shop.setAddress("������̫����·");
//		shop.setDutyId(2L);
//		shop.setPassword("�׾�");
//		shop.setRemarks("С�������콢��");
//		shop.setTel(18859764255L);
//		shop.setShop("��������");
//		List<ShopperBean> list = ShopperUtil.selectAll(null);
//		for (ShopperBean s : list) {
//			System.out.println(s.toString());
//		}
//		long id = 1L;
//		ShopperUtil.add(shop);
//		ShopperUtil.delete(2L);
//		ShopperUtil.update(shop);
//		File file= new File("D:\\shopping.xlsx");
//		try {
//			Workbook book = Workbook.getWorkbook(file);
//			Sheet sheet = book.getSheet(0);
//			Cell cell = sheet.getCell(0,0);
//			String ss = cell.getContents();
//			System.out.println(ss);
//			book.close();
//		} catch (BiffException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		List<ShoppingBean> list = DBUtil.impExcel(file);
//		for (ShoppingBean s : list) {
//			System.out.println(s.toString());
//		}
		
	}
}
