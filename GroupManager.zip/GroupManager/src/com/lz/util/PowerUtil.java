package com.lz.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import com.lz.dao.PowerBeanMapper;
import com.lz.domin.PageBean;
import com.lz.entity.PowerBean;

public class PowerUtil {
	public static List<PowerBean> selectAll(PageBean page){
		Map<String,Object> map = new HashMap<String,Object>();
		SqlSession session  = MybatisSessionFactory.getSession();
		PowerBeanMapper mapper = session.getMapper(PowerBeanMapper.class);
		if(page!=null&&page.getPageNum()>0){
			if(page.getPageNum()<1){
				page.setPageNum(1);
			}
			if(page.getMaxPage()<1){
				int rows = mapper.getRows(map);
				if(rows<1){
					return null;
				}
				int max = (rows-1+page.getRowsPerPage())/page.getRowsPerPage();
				page.setRowsNum(rows);
				page.setMaxPage(max);
			}
			if(page.getPageNum()>page.getMaxPage()){
				page.setPageNum(page.getMaxPage());
			}
			map.put("pageNum", page.getPageNum());
			map.put("pageRows",page.getRowsPerPage());
		}
		List<PowerBean> list = mapper.selectAll(map);	
		return list;			
	}

	public  static void add(PowerBean s){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			PowerBeanMapper mapper = session.getMapper(PowerBeanMapper.class);
			int len = mapper.insert(s);
			System.out.println(len+"���������ӳɹ�");			
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}

	public static void delete(Long id){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			PowerBeanMapper mapper = session.getMapper(PowerBeanMapper.class);
			int len = mapper.deleteById(id);
			System.out.println(len+"������ɾ���ɹ�");
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}
	public static void update(PowerBean s){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			PowerBeanMapper mapper = session.getMapper(PowerBeanMapper.class);
			int len = mapper.update(s);		
			System.out.println(len+"�����ݸ��³ɹ�");	
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}
	public static PowerBean look(Long id){
		SqlSession session  = MybatisSessionFactory.getSession();
		PowerBeanMapper mapper = session.getMapper(PowerBeanMapper.class);
		PowerBean power = mapper.select(id);
			System.out.println(power.toString());	
			return power;
	}

}
