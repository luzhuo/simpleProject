package com.lz.util;

import com.lz.biz.ShopperServ;
import com.lz.biz.ShoppingServ;
import com.lz.biz.Impl.ShopperSerImpl;
import com.lz.biz.Impl.ShoppingSerImpl;
import com.lz.entity.ShoppingBean;

public class DaoFactory {
	public static ShoppingBean getShopping(){
		return new ShoppingBean();
	}
	public static ShoppingServ getShoppingServ(){
		return new ShoppingSerImpl();
	}
	public static ShopperServ getShopperServ(){
		return new ShopperSerImpl();
	}
	
}
