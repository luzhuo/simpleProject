package com.lz.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.apache.ibatis.session.SqlSession;

import com.lz.dao.ShoppingBeanMapper;
import com.lz.domin.PageBean;
import com.lz.entity.ShoppingBean;

public class DBUtil {
	public static List<ShoppingBean> impExcel(File file) throws Exception{	
		List<ShoppingBean> list = new ArrayList<ShoppingBean>();
		Workbook book =Workbook.getWorkbook(file);
		Sheet sheet = book.getSheet(0);
		int rows = sheet.getRows();//����
		for (int i = 1; i < rows; i++) {
			Cell cell = sheet.getCell(0, i);
			String contents = cell.getContents();
			ShoppingBean shopping = new ShoppingBean();
			Long id =null;
			if(cell!=null){
				try {
					id=Long.parseLong(contents.trim());
				} catch (Exception e) {
					id=null;
					System.out.println("excelIdת������");
				}
				shopping.setId(id);
			}
			cell = sheet.getCell(1, i);
			contents = cell.getContents();
			if(cell!=null){
				String goods = new String(contents);
				shopping.setGoods(goods);
			}
			cell = sheet.getCell(2, i);
			contents = cell.getContents();
			if(cell!=null){
				String address = new String(contents);
				shopping.setGoods(address);
			}
			cell = sheet.getCell(3, i);
			contents = cell.getContents();
			Double price = null;
			if(cell!=null){
				try {
					price = Double.parseDouble(contents.trim());
				} catch (Exception e) {
					price=null;
					System.out.println("ExcelPriceת������");
				}
				shopping.setPrice(price);
			}
			list.add(shopping);
		}
		book.close();
		return list;
	}
	
	
	public static List<ShoppingBean> selectAll(PageBean page){
		Map<String,Object> map = new HashMap<String,Object>();
		SqlSession session  = MybatisSessionFactory.getSession();
		ShoppingBeanMapper mapper = session.getMapper(ShoppingBeanMapper.class);
		if(page!=null&&page.getPageNum()>0){
			if(page.getPageNum()<1){
				page.setPageNum(1);
			}
			if(page.getMaxPage()<1){
				int rows = mapper.getRows(map);
				if(rows<1){
					return null;
				}
				int max = (rows-1+page.getRowsPerPage())/page.getRowsPerPage();
				page.setRowsNum(rows);
				page.setMaxPage(max);
			}
			if(page.getPageNum()>page.getMaxPage()){
				page.setPageNum(page.getMaxPage());
			}
			map.put("pageNum", page.getPageNum());
			map.put("pageRows",page.getRowsPerPage());
		}
		List<ShoppingBean> list = mapper.selectAll(map);	
		return list;			
	}

	public  static void add(ShoppingBean s){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			ShoppingBeanMapper mapper = session.getMapper(ShoppingBeanMapper.class);
			int len = mapper.insert(s);
			System.out.println(len+"���������ӳɹ�");			
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}

	public static void delete(Long id){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			ShoppingBeanMapper mapper = session.getMapper(ShoppingBeanMapper.class);
			int len = mapper.deleteById(id);
			System.out.println(len+"������ɾ���ɹ�");
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}
	public static void update(ShoppingBean shopping){
		try {
			SqlSession session  = MybatisSessionFactory.getSession();
			ShoppingBeanMapper mapper = session.getMapper(ShoppingBeanMapper.class);
			int len = mapper.	update(shopping);		
			System.out.println(len+"�����ݸ��³ɹ�");	
			MybatisSessionFactory.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			MybatisSessionFactory.rollbackTransaction();
		}finally{
			MybatisSessionFactory.closeSession();
		}
	}
	public static ShoppingBean look(Long id){
		SqlSession session  = MybatisSessionFactory.getSession();
		ShoppingBeanMapper mapper = session.getMapper(ShoppingBeanMapper.class);
			 return mapper.select(id);
			
	}
}
