package com.lz.biz;

import java.util.List;

import com.lz.entity.ShopperBean;;

public interface ShopperServ {
	public void creat(ShopperBean shopper) throws Exception;
	public List<ShopperBean> getList()throws Exception;

}
