package com.lz.biz;

import java.util.List;
import com.lz.entity.ShoppingBean;

public interface ShoppingServ {
	public void creat(ShoppingBean shopping) throws Exception;
	public List<ShoppingBean> getList()throws Exception;

}
