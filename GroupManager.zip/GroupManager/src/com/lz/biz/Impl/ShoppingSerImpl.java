package com.lz.biz.Impl;

import java.util.List;

import com.lz.biz.ShoppingServ;
import com.lz.entity.ShoppingBean;
import com.lz.util.DBUtil;

public class ShoppingSerImpl implements ShoppingServ{

	@Override
	public void creat(ShoppingBean shopping) throws Exception {
		DBUtil.add(shopping);		
	}

	@Override
	public List<ShoppingBean> getList() throws Exception {
		
		return null;
	}

}
