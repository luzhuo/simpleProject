package com.lz.biz.Impl;

import java.util.List;

import com.lz.biz.ShopperServ;
import com.lz.entity.ShopperBean;
import com.lz.util.ShopperUtil;

public class ShopperSerImpl implements ShopperServ{

	@Override
	public void creat(ShopperBean shopper) throws Exception {
		ShopperUtil.add(shopper);		
	}

	@Override
	public List<ShopperBean> getList() throws Exception {
		
		return null;
	}

}
