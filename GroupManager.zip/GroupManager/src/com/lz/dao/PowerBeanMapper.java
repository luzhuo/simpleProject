package com.lz.dao;

import java.util.List;
import java.util.Map;
import com.lz.entity.PowerBean;

public interface PowerBeanMapper {
	int insert(PowerBean record);

    int insertSelective(PowerBean record);
    
    int update(PowerBean shopper);
	
    PowerBean select(Long id);
    
    int deleteById(Long id);
    
    List<PowerBean> selectAll(Map<String,Object> map);
    
    int getRows(Map<String,Object> map);
}