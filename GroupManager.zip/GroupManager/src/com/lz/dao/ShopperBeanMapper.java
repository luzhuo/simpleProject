package com.lz.dao;

import java.util.List;
import java.util.Map;

import com.lz.entity.ShopperBean;

public interface ShopperBeanMapper {
    int insert(ShopperBean record);

    int insertSelective(ShopperBean record);
    
    int update(ShopperBean shopper);
	
    ShopperBean select(Long id);
    
    int deleteById(Long id);
    
    List<ShopperBean> selectAll(Map<String,Object> map);
    
    int getRows(Map<String,Object> map);
}