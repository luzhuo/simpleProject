package com.lz.dao;

import java.util.List;
import java.util.Map;

import com.lz.entity.ShoppingBean;

public interface ShoppingBeanMapper {
	int update(ShoppingBean shopping);
	
	ShoppingBean select(Long id);
	
    int insert(ShoppingBean shopping);
    
    int insertSelective(ShoppingBean record);
    
    int deleteById(Long id);
    
    List<ShoppingBean> selectAll(Map<String,Object> map);
    
    int getRows(Map<String,Object> map);
}