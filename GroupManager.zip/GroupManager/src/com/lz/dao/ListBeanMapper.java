package com.lz.dao;

import java.util.List;
import java.util.Map;

import com.lz.entity.ListBean;

public interface ListBeanMapper {
	int insert(ListBean record);

    int insertSelective(ListBean record);
    
    int update(ListBean shopper);
	
    ListBean select(Long id);
    
    int deleteById(Long id);
    
    List<ListBean> selectAll(Map<String,Object> map);
    
    int getRows(Map<String,Object> map);
}