package com.lz.dao;

import java.util.List;
import java.util.Map;

import com.lz.entity.ManagerBean;
public interface ManagerBeanMapper {
	 int insert(ManagerBean record);

	    int insertSelective(ManagerBean record);
	    
	    int update(ManagerBean shopper);
		
	    ManagerBean select(String name);
	    
	    int deleteById(Long id);
	    
	    List<ManagerBean> selectAll(Map<String,Object> map);
	    
	    int getRows(Map<String,Object> map);
}