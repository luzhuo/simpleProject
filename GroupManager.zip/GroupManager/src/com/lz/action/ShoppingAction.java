package com.lz.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lz.biz.ShoppingServ;
import com.lz.domin.PageBean;
import com.lz.entity.ShoppingBean;
import com.lz.util.DBUtil;
import com.lz.util.DaoFactory;
import com.lz.util.StringUtil;


public class ShoppingAction extends BaseAction{
	private static final long serialVersionUID = 1L;
	private static ShoppingServ spserv= DaoFactory.getShoppingServ();
	private int rowsPerPage;
	private static Long goodsId;

	public void edit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ShoppingBean shopping = new ShoppingBean();
		if(goodsId!=null)
		shopping.setId(goodsId);
		String method = request.getMethod();
		System.out.println(method);
		if("POST".equals(method)){		
			String goods = request.getParameter("goods");
			String address = request.getParameter("address");
			String prices = request.getParameter("price");
			Map<String,String> errs = new HashMap<String,String>();
			if(StringUtil.isBlank(goods)){
				errs.put("goods", "��Ʒ���Ʋ���Ϊ��");
			}
			if(StringUtil.isBlank(address)){
				errs.put("address", "��Ʒ��ַ����Ϊ��");
			}
			Double price = null;	
			if(StringUtil.isBlank(prices)){
				errs.put("price", "��Ʒ�۸���Ϊ��");
			}else{
				try {
					price = Double.valueOf(prices.trim());
				} catch (Exception e) {
					errs.put("price", "�۸��ʽ����ȷ");
				}
			}
			if(!errs.isEmpty()){
				request.setAttribute("errors", errs);
				request.getRequestDispatcher("/goods/editgoods.jsp").forward(request, response);
				return;
			}
			try {
				
				if(!StringUtil.isBlank(address)){
				shopping.setAddress(address);
				}
				if(!StringUtil.isBlank(goods)){
				shopping.setGoods(goods);
				}
				if(price!=null){
				shopping.setPrice(price);
				}
				DBUtil.update(shopping);
				HttpSession session = request.getSession();
				session.setAttribute("success", "����"+goods+"��Ʒ�ɹ�");
				request.getRequestDispatcher("/goods/editgoods.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}	
					
		}else{
			System.out.println("��post�ύ");
			request.getRequestDispatcher("/goods/editgoods.jsp").forward(request, response);
		}
	}
	public void modify(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String[] var = request.getParameterValues("checkbox2");
		if(var!=null&&var.length>0){
			for (String ss:var) {
				try {
					goodsId=Long.parseLong(ss);
					
				} catch (Exception e) {
					goodsId=null;
				}
			}
			if(goodsId!=null){
				ShoppingBean shopping = DBUtil.look(goodsId);
				request.setAttribute("shopping", shopping);
				request.getRequestDispatcher("/goods/editgoods.jsp").forward(request, response);
				return;
			}
		}
		response.sendRedirect(this.getServletContext().getContextPath()+"/goods/editgoods.jsp");
}
	
	public void delall(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String[] var = request.getParameterValues("checkbox2");
		if(var!=null&&var.length>0){
			for (String ss:var) {
				Long id=null;
				try {
					id=Long.parseLong(ss);
				} catch (Exception e) {
					id=null;
					System.out.println("ɾ��idֵת������");
				}
				if(id!=null){
					System.out.println("ִ��ɾ��");
					DBUtil.delete(id);
				}
			}
		}
		response.sendRedirect(this.getServletContext().getContextPath()+"/goods/goodslist.jsp");
	}
	public void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getMethod();
		System.out.println(method);
		if("POST".equals(method)){		
			String goods = request.getParameter("goods");
			String address = request.getParameter("address");
			String prices = request.getParameter("price");
			Map<String,String> errs = new HashMap<String,String>();
			if(StringUtil.isBlank(goods)){
				errs.put("goods", "��Ʒ���Ʋ���Ϊ��");
			}
			if(StringUtil.isBlank(address)){
				errs.put("address", "��Ʒ��ַ����Ϊ��");
			}
			Double price = null;	
			if(StringUtil.isBlank(prices)){
				errs.put("price", "��Ʒ�۸���Ϊ��");
			}else{
				try {
					price = Double.valueOf(prices.trim());
				} catch (Exception e) {
					errs.put("price", "�۸��ʽ����ȷ");
				}
			}
			if(!errs.isEmpty()){
				request.setAttribute("errors", errs);
				request.getRequestDispatcher("/goods/addgoods.jsp").forward(request, response);
				return;
			}
			try {
				ShoppingBean shopping = new ShoppingBean();
				if(!StringUtil.isBlank(address)){
				shopping.setAddress(address);
				}
				if(!StringUtil.isBlank(goods)){
				shopping.setGoods(goods);
				}
				if(price!=null){
				shopping.setPrice(price);
				}
				spserv.creat(shopping);
				HttpSession session = request.getSession();
				session.setAttribute("success", "����"+goods+"��Ʒ�ɹ�");
				response.sendRedirect("/goods/addgoods.jsp?action=add");
			} catch (Exception e) {
				System.out.println("");
				e.printStackTrace();
			}	
					
		}else{
			System.out.println("��post�ύ");
			request.getRequestDispatcher("/goods/addgoods.jsp").forward(request, response);
		}
		
	}
	
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			Integer pageNum = null;
			String ss = request.getParameter("page");
			try {
				pageNum = Integer.parseInt(ss);
			} catch (Exception e) {
				pageNum = 1;
			}		
			PageBean page = new PageBean();
			if(pageNum!=null){
			page.setPageNum(pageNum);
			}
			page.setRowsPerPage(rowsPerPage);
			List<ShoppingBean> list = DBUtil.selectAll(page);
			request.setAttribute("pages", page);		
			request.setAttribute("ShoppingList", list);
			request.getRequestDispatcher("/goods/goodslist.jsp").forward(request, response);	
	}
	@Override
	public void init(ServletConfig config) throws ServletException {		
		super.init(config);
		String ss = config.getInitParameter("rowsPerPage");
		try {
			rowsPerPage = Integer.parseInt(ss);
		} catch (Exception e) {
			rowsPerPage =15;
		}
	}
}
