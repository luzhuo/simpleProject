package com.lz.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.lz.biz.ShopperServ;
import com.lz.domin.PageBean;
import com.lz.entity.ShopperBean;
import com.lz.util.DaoFactory;
import com.lz.util.ShopperUtil;
import com.lz.util.StringUtil;


public class ShopperAction extends BaseAction{
	private static final long serialVersionUID = 1L;
	private static ShopperServ spserv= DaoFactory.getShopperServ();
	private int rowsPerPage;

	public void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getMethod();
		System.out.println(method);
		if("POST".equals(method)){	
			String shop = request.getParameter("shop");
			String address = request.getParameter("address");
			String password = request.getParameter("password");//������
			String stel = request.getParameter("tel");
			String remarks = request.getParameter("remarks");//��ע
			String sduty_Id = request.getParameter("duty_Id");
			
			Map<String,String> errs = new HashMap<String,String>();
			if(StringUtil.isBlank(shop)){
				errs.put("shop", "�̻����Ʋ���Ϊ��");
			}
			if(StringUtil.isBlank(password)){
				errs.put("password", "�����˲���Ϊ��");
			}
			if(StringUtil.isBlank(address)){
				errs.put("address", "��Ʒ��ַ����Ϊ��");
			}
			if(StringUtil.isBlank(remarks)){
				errs.put("remarks", "�̻�˵������Ϊ��");
			}
			
			Long tel = null;	
			if(StringUtil.isBlank(stel)){
				errs.put("tel", "��ϵ��ʽ����Ϊ��");
			}else{
				try {
					tel = Long.parseLong(stel);
				} catch (Exception e) {
					errs.put("price", "�۸��ʽ����ȷ");
				}
			}
			Long duty_Id = null;	
			if(StringUtil.isBlank(sduty_Id)){
				errs.put("duty_Id", "����id����Ϊ��");
			}else{
				try {
					duty_Id = Long.parseLong(sduty_Id);
				} catch (Exception e) {
					errs.put("duty_Id", "����id��ʽ����ȷ");
				}
			}
			if(!errs.isEmpty()){
				request.setAttribute("errors", errs);
				request.getRequestDispatcher("/shoppe/addshoppe.jsp").forward(request, response);
				return;
			}
			try {
				ShopperBean shopper = new ShopperBean();
				if(!StringUtil.isBlank(address)){
				shopper.setAddress(address);
				}
				if(!StringUtil.isBlank(shop)){
				shopper.setShop(shop);
				}
				if(!StringUtil.isBlank(remarks)){
					shopper.setRemarks(remarks);
					}
				if(!StringUtil.isBlank(password)){
					shopper.setPassword(password);
					}
				if(tel!=null){
					shopper.setTel(tel);
				}
				if(duty_Id!=null){
					shopper.setDutyId(duty_Id);
				}
				spserv.creat(shopper);
				HttpSession session = request.getSession();
				session.setAttribute("success", "����"+shop+"�̻��ɹ�");
				response.sendRedirect(request.getContextPath()+"/shoppe/addshoppe.jsp?action=add");
			} catch (Exception e) {
				e.printStackTrace();
			}						
		}else{
			request.getRequestDispatcher("/shoppe/addshoppe.jsp").forward(request, response);
		}
		
	}
	
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			Integer pageNum = null;
			String ss = request.getParameter("page");
			try {
				pageNum = Integer.parseInt(ss);
			} catch (Exception e) {
				pageNum = 1;
				System.out.println("page��������ת������");
			}		
			PageBean page = new PageBean();
			if(pageNum!=null){
			page.setPageNum(pageNum);
			}
			page.setRowsPerPage(rowsPerPage);
			List<ShopperBean> list = ShopperUtil.selectAll(page);
			request.setAttribute("pages", page);		
			request.setAttribute("ShopperList", list);
			request.getRequestDispatcher("/shoppe/shoppelist.jsp").forward(request, response);	
	}
	@Override
	public void init(ServletConfig config) throws ServletException {		
		super.init(config);
		String ss = config.getInitParameter("rowsPerPage");
		try {
			rowsPerPage = Integer.parseInt(ss);
		} catch (Exception e) {
			rowsPerPage =15;
		}
	}
}
