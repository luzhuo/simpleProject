package com.lz.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lz.domin.PageBean;
import com.lz.entity.ManagerBean;
import com.lz.util.ManagerUtil;
import com.lz.util.StringUtil;

public class ManagerAction extends BaseAction {

	private static final long serialVersionUID = 2010304953038202724L;
	private int rowsPerPage;
	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Boolean res = false;
		Map<String,String> errs= new HashMap<String,String>();
		HttpSession session = request.getSession();
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		//String checkcode = request.getParameter("checkcode");
		if(StringUtil.isBlank(name))
			errs.put("NoUser", "�û�������Ϊ��");
			
		if(StringUtil.isBlank(password))
			errs.put("NoPassword", "���벻��Ϊ��");
			
//		if(StringUtil.isBlank(checkcode)){
//			errs.put("NoCheckCode", "��֤�벻��Ϊ��");	
//			}else{
//			Object obj = session.getAttribute("checkcode");
//			//System.out.println(obj+ "and"+checkcode);
//			if(!checkcode.equals(obj)){
//				errs.put("NoCheckCode", "��֤���������!");
//				}
//			session.removeAttribute("checkcode");
//		}
		
		if(!errs.isEmpty()){
			session.setAttribute("errors", errs);
			session.setAttribute("user", name);
			response.sendRedirect("/GroupManager/login.jsp");
			return;
		}
		ManagerBean manager = null;
		 manager = ManagerUtil.look(name);
		if(password!=null&&manager!=null){
			if((manager.getPassword()).equals(password)){
				res=true;
			}
		}
		
		if(res){
			session.setAttribute("user", manager);
			response.sendRedirect("/GroupManager/index.jsp");
		}else{
			errs.put("NotUserOrPass", "�û��������������");
			session.setAttribute("errors", errs);
			response.sendRedirect("/GroupManager/login.jsp");
		}
		
	}

	public void edit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}
	public void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Integer pageNum = null;
		String ss = request.getParameter("page");
		try {
			pageNum = Integer.parseInt(ss);
		} catch (Exception e) {
			pageNum = 1;
		}		
		PageBean page = new PageBean();
		if(pageNum!=null){
		page.setPageNum(pageNum);
		}
		page.setRowsPerPage(rowsPerPage);
		List<ManagerBean> list = ManagerUtil.selectAll(page);
		request.setAttribute("pages", page);		
		request.setAttribute("ManagerList", list);
		request.getRequestDispatcher("/user/userlist.jsp").forward(request, response);	

	}
	public void init(ServletConfig config) throws ServletException {		
		super.init(config);
		String ss = config.getInitParameter("rowsPerPage");
		try {
			rowsPerPage = Integer.parseInt(ss);
		} catch (Exception e) {
			rowsPerPage =15;
		}
	}

}
