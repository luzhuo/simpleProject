package com.lz.entity;

public class ShoppingBean {
    @Override
	public String toString() {
		return "ShoppingBean [id=" + id + ", goods=" + goods + ", price="
				+ price + ", address=" + address + "]";
	}

	private Long id;

    private String goods;

    private double price;

    private String address;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGoods() {
        return goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}