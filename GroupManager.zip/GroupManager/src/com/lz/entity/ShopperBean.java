package com.lz.entity;

public class ShopperBean {
    @Override
	public String toString() {
		return "ShopperBean [id=" + id + ", shop=" + shop + ", password="
				+ password + ", tel=" + tel + ", address=" + address
				+ ", remarks=" + remarks + ", dutyId=" + duty_Id + "]";
	}

	private Long id;

    private String shop;

    private String password;

    private Long tel;

    private String address;

    private String remarks;

    private Long duty_Id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShop() {
        return shop;
    }

    public void setShop(String shop) {
        this.shop = shop;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getTel() {
        return tel;
    }

    public void setTel(Long tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Long getDutyId() {
        return duty_Id;
    }

    public void setDutyId(Long dutyId) {
        this.duty_Id = dutyId;
    }
}