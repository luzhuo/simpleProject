package com.lz.entity;

public class PowerBean {
    @Override
	public String toString() {
		return "PowerBean [id=" + id + ", name=" + name + "]";
	}

	private Short id;

    private String name;
    
    private ListBean power = new ListBean();

    public ListBean getPower() {
		return power;
	}

	public void setPower(ListBean power) {
		this.power = power;
	}

	public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}