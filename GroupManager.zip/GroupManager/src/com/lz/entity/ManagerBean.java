package com.lz.entity;

public class ManagerBean {
    @Override
	public String toString() {
		return "ManagerBean [id=" + id + ", name=" + name + ", password="
				+ password + ", tel=" + tel + ", power=" + power + ", remarks="
				+ remarks + ", ip=" + ip + "]";
	}

	private Long id;

    private String name;

    private String password;

    private Long tel;

    private Short power;
    
    private PowerBean power_name = new PowerBean();

    public PowerBean getPower_name() {
		return power_name;
	}

	public void setPower_name(PowerBean power_name) {
		this.power_name = power_name;
	}

	private String remarks;

    private String ip;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getTel() {
        return tel;
    }

    public void setTel(Long tel) {
        this.tel = tel;
    }

    public Short getPower() {
        return power;
    }

    public void setPower(Short power) {
        this.power = power;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}