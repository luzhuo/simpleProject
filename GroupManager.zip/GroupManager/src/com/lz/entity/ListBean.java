package com.lz.entity;

public class ListBean {
    @Override
	public String toString() {
		return "ListBean [id=" + id + ", title=" + title + ", url=" + url
				+ ", parentId=" + parentId + ", menu=" + menu + "]";
	}

	private Short id;

    private String title;

    private String url;

    private Short parentId;

    private Short menu;

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Short getParentId() {
        return parentId;
    }

    public void setParentId(Short parentId) {
        this.parentId = parentId;
    }

    public Short getMenu() {
        return menu;
    }

    public void setMenu(Short menu) {
        this.menu = menu;
    }
}