insert into t_users(id,username,password,role_id) values(seq_users.nextval,'lz','123456',2)
insert into t_roles(id,name,meno) values(seq_roles.nextval,'总管','公司部门总管');