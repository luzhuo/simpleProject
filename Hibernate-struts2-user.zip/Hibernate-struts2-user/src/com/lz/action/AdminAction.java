package com.lz.action;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.lz.biz.UserSer;
import com.lz.domin.PageBean;
import com.lz.entity.UserBean;
import com.lz.util.BizFactory;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.ValueStack;
@ParentPackage("admin")
@Namespace("/user")
public class AdminAction extends ActionSupport implements ModelDriven<UserBean>{
	private UserBean user = new UserBean();
	private PageBean pages = new PageBean();
	private int rowsPerPage = 15;
	private static final long serialVersionUID = 1338335967547235403L;
	private UserSer userSer = BizFactory.getUser();
	@Action(value="list",results={
			@Result(name="success",location="/WEB-INF/content/user/list.jsp")
	})
	public String list() throws Exception{
		pages.setRowsPerPage(rowsPerPage);
		List<UserBean> list = userSer.list(user, pages);		
		ActionContext.getContext().put("userList", list);		
		return SUCCESS;
	}
	@Action(value="load",results={
			@Result(name="success",location="/WEB-INF/content/user/update.jsp")
			})
	public String load() throws Exception{
		UserBean temp = userSer.load(user.getId());
		ValueStack value = ActionContext.getContext().getValueStack();
		value.pop();
		value.push(temp);
		return SUCCESS;
	}
	@Action(value="del",results={
			@Result(name="success",type="redirectAction",params={"actionName","list"})
			})
	public String del() throws Exception{
		userSer.romove(user.getId());	
		return SUCCESS;
	}
	public UserBean getModel() {
		return user;
	}
}
