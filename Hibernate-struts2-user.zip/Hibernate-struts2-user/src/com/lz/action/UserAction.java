package com.lz.action;

import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.SessionAware;

import com.lz.biz.UserSer;
import com.lz.entity.UserBean;
import com.lz.util.BizFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
@ParentPackage("fronter")
@Namespace("/")
public class UserAction extends ActionSupport implements ModelDriven<UserBean>,SessionAware{
	private UserBean user = new UserBean();
	private Map<String, Object> session;
	private UserSer userSer = BizFactory.getUser();
	private static final long serialVersionUID = 1338335967547235403L;
	@Action(value="tologin",results={
			@Result(name="success",location="/WEB-INF/content/user/login.jsp")
	})
	public String toLogin(){
		return SUCCESS;
	}
	@Action(value="login",results={
			@Result(name="success",type="redirect",location="/user/list.action"),
			@Result(name="input",location="/WEB-INF/content/user/login.jsp")
	})
	public String Login() throws Exception{
		boolean bb = false;
		try {
			bb = userSer.login(user);
		} catch (Exception e) {
			this.addActionError("用户名不能为空");
			return INPUT;
		}
		
		if(bb){
			session.put("user", user);
		return SUCCESS;
		}else{
			this.addActionError("用户名或者密码错误");
			return INPUT;
		}
	}
	public UserBean getModel() {		
		return user;
	}
	public void setSession(Map<String, Object> arg0) {
		this.session=arg0;
		
	}
}
