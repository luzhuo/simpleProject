package com.lz.dao;

import com.lz.entity.UserBean;

public interface UserDao extends BaseDao<UserBean, Long> {

}
