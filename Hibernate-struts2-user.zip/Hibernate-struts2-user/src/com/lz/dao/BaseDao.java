package com.lz.dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao <T extends Serializable, ID extends Serializable> {
	
	public T save(T record);
	public T delete(T record);
	public T load(ID id);
	public T update(T record);
	List<T> selectByExample(T record, int... pages);
	int selectByExampleRowsNum(T record);

}
