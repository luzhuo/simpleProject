package com.lz.dao;

import com.lz.entity.RoleBean;

public interface RoleDao extends BaseDao<RoleBean, Long> {

}
