package com.lz.dao.impl;

import com.lz.dao.RoleDao;
import com.lz.entity.RoleBean;

public class RoleDaoImpl extends BaseDaoImpl<RoleBean,Long> implements RoleDao{

}
