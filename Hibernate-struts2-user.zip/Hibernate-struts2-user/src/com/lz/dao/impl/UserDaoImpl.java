package com.lz.dao.impl;
import com.lz.dao.UserDao;
import com.lz.entity.UserBean;

public class UserDaoImpl extends BaseDaoImpl<UserBean,Long> implements UserDao{

}
