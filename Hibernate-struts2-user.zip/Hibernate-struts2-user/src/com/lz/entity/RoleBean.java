package com.lz.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;


@Entity(name="t_roles")
@SequenceGenerator(name="seq2",sequenceName="seq_roles" ,initialValue=1)
public class RoleBean implements Serializable{
	
	private static final long serialVersionUID = 4782342367013106705L;
	@Id
	@GeneratedValue(generator="seq2",strategy=GenerationType.SEQUENCE)
	private Long id;
	@Column(length=32,nullable=false,unique=true)
	private String name;
	@Basic(fetch=FetchType.LAZY)
	@Column(length=200)
	private String meno;
	@OneToMany(mappedBy="role",cascade=CascadeType.ALL)
	private Set<UserBean> user = new HashSet<UserBean>();

	//====================
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMeno() {
		return meno;
	}
	public void setMeno(String meno) {
		this.meno = meno;
	}
	public Set<UserBean> getUser() {
		return user;
	}
	public void setUser(Set<UserBean> user) {
		this.user = user;
	}
	
	

}
