package com.lz.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@SuppressWarnings("deprecation")
@Entity(name="t_users")
@org.hibernate.annotations.Entity(dynamicInsert=true)
@SequenceGenerator(name="seq1",sequenceName="seq_users" ,initialValue=1)
public class UserBean implements Serializable{
	private static final long serialVersionUID = 7266705052703911534L;
	@Id
	@GeneratedValue(generator="seq1",strategy=GenerationType.SEQUENCE)
	private Long id;
	@Column(length=32,nullable=false,unique=true)
	private String username;
	@Column(length=32,nullable=false,unique=true)
	private String password;
	@Transient
	private String repassword;
	@Column(columnDefinition="varchar2(50) default 'images/1.jpg'")
	private String pic;
	@Temporal(TemporalType.DATE)
	@Column(columnDefinition="date default sysdate")
	private Date hirdate;
	@Column(columnDefinition="number(1) default 1")
	private Boolean sex;
	@Column(columnDefinition="number(8,2) default 0.00")
	private Double salary;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="role_id")
	private RoleBean role;
	
	//========================
	
	public String getRepassword() {
		return repassword;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Date getHirdate() {
		return hirdate;
	}
	public void setHirdate(Date hirdate) {
		this.hirdate = hirdate;
	}
	public Boolean getSex() {
		return sex;
	}
	public void setSex(Boolean sex) {
		this.sex = sex;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public RoleBean getRole() {
		return role;
	}
	public void setRole(RoleBean role) {
		this.role = role;
	}
	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hirdate == null) ? 0 : hirdate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((pic == null) ? 0 : pic.hashCode());
		result = prime * result
				+ ((repassword == null) ? 0 : repassword.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		result = prime * result + ((salary == null) ? 0 : salary.hashCode());
		result = prime * result + ((sex == null) ? 0 : sex.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBean other = (UserBean) obj;
		if (hirdate == null) {
			if (other.hirdate != null)
				return false;
		} else if (!hirdate.equals(other.hirdate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (pic == null) {
			if (other.pic != null)
				return false;
		} else if (!pic.equals(other.pic))
			return false;
		if (repassword == null) {
			if (other.repassword != null)
				return false;
		} else if (!repassword.equals(other.repassword))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		if (sex == null) {
			if (other.sex != null)
				return false;
		} else if (!sex.equals(other.sex))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
}
