package com.lz.biz;

import java.util.List;

import com.lz.domin.PageBean;
import com.lz.entity.UserBean;

public interface UserSer {
	public boolean login(UserBean user) throws Exception;
	public List<UserBean> list(UserBean user,PageBean pages) throws Exception;
	public void romove(Long id) throws Exception;
	public UserBean load(Long id) throws Exception;
}
