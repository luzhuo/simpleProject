package com.lz.biz.impl;

import com.lz.biz.RoleSer;

public class RoleSerImpl implements RoleSer {

}
