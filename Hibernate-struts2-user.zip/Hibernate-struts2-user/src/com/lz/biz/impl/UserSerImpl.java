package com.lz.biz.impl;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.lz.biz.UserSer;
import com.lz.dao.UserDao;
import com.lz.domin.PageBean;
import com.lz.entity.UserBean;
import com.lz.util.DaoFactory;

public class UserSerImpl implements UserSer{
	private UserDao userDao = DaoFactory.getUser();
	
	public boolean login(UserBean user) throws Exception {
		if(user==null||user.getUsername()==null||user.getPassword()==null||user.getUsername().trim().length()<1){
			throw new Exception("参数错误");
		}
		List<UserBean> list = userDao.selectByExample(user);
		if(list!=null&& list.size()>0){
			UserBean temp = list.get(0);
			BeanUtils.copyProperties(user, temp);
			return true;
		}		
		return false;
	}

	public List<UserBean> list(UserBean user, PageBean pages) throws Exception {
		
		if(pages!=null&&pages.getRowsPerPage()>0){
			if(pages.getPageNum()<1){
				pages.setPageNum(1);
			}
			if(pages.getMaxPage()<1){
				int rows= userDao.selectByExampleRowsNum(user);
				if(rows<1){
					return null;
				}
				int max = (rows-1+pages.getRowsPerPage())/pages.getRowsPerPage();
				pages.setRowsNum(rows);
				pages.setMaxPage(max);
			}
				if(pages.getPageNum()>pages.getMaxPage()){
					pages.setPageNum(pages.getMaxPage());
					}
				int begin = (pages.getPageNum()-1)*pages.getRowsPerPage();
				return userDao.selectByExample(user,begin,pages.getRowsPerPage());
		}
		
		return userDao.selectByExample(user);
	}

	public void romove(Long id) throws Exception {
		if(id!=null){
			UserBean user = userDao.load(id);
			if(user!=null){
			userDao.delete(user);
			}
		}
		
	}

	public UserBean load(Long id) throws Exception{
		
		if(id!=null&&id>0){
			return  userDao.load(id);
		}
		return null;
	}

}
