package com.lz.biz;

public interface RoleSer {

}
