package com.lz.util;

import com.lz.biz.RoleSer;
import com.lz.biz.UserSer;
import com.lz.biz.impl.RoleSerImpl;
import com.lz.biz.impl.UserSerImpl;

public class BizFactory {
	private BizFactory(){
		
	}
	public static RoleSer getRole(){
		return new RoleSerImpl();
	}
	public static UserSer getUser(){
		return new UserSerImpl();
	}

}
