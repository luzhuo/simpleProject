package com.lz.util;

import com.lz.dao.RoleDao;
import com.lz.dao.UserDao;
import com.lz.dao.impl.RoleDaoImpl;
import com.lz.dao.impl.UserDaoImpl;

public class DaoFactory {
	public static UserDao getUser(){
		return new UserDaoImpl();
	}
	public static RoleDao getRole(){
		return new RoleDaoImpl();
	}

}
