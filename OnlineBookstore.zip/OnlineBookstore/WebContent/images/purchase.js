function winopenlocation(){
window.open("history.asp","","top=100,left=100,toolbar=no,menubar=no,scrollbars=yes,resizable=no,location=no, status=no,width=400,height=240");
}

