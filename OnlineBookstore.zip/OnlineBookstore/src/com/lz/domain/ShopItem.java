package com.lz.domain;

import java.io.Serializable;

import com.lz.entily.BookBean;

public class ShopItem implements Serializable {

	private static final long serialVersionUID = 3573142014731677297L;
	
	private BookBean book;
	private int num;
	public double getAllPrice() {
		return book.getPrice()*num;
	}
	
	public BookBean getBook() {
		return book;
	}
	public void setBook(BookBean book) {
		this.book = book;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	

}
