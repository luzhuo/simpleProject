package com.lz.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.lz.entily.BookBean;

public class ShopCart implements Serializable {

	private static final long serialVersionUID = 6468991685142765700L;

	private Map<Long,ShopItem> cart = new HashMap<Long,ShopItem>();
	public Collection<ShopItem> getAllItems(){
		return cart.values();
	}
	
	public double getAllMoney(){
		double b =0;
		for (ShopItem temp : getAllItems()) {
			b+=temp.getAllPrice();
		}
		return b;
	}
	public void add(BookBean book){
		ShopItem item = null;
		if(cart.containsKey(book.getId())){
			item=cart.get(book.getId());
			item.setNum(item.getNum()+1);
		}else{
			item = new ShopItem();
			item.setNum(1);
			item.setBook(book);
		}
		cart.put(book.getId(),item);
	}

	public void clear() {
		cart.clear();
	}

	public void refresh(Long ids, Integer nums) {
		if(cart.containsKey(ids)){
			if(nums>0){
				ShopItem item = cart.get(ids);
				item.setNum(nums);
			}else{
				cart.remove(ids);
			}
		}
	}
}
