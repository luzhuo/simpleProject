package com.lz.domain;

import java.io.Serializable;

public class PageBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1803418069950099211L;
	private int pageNum;//��ǰҳ��ֵ
	private int rowsNum;//������
	private int maxPage;//���ҳ��
	private int rowsPerPage = 15;//ÿҳ����
	public static int PAGE_NUM =5;
	public int getStartPage(){
		if(pageNum>PAGE_NUM/2)
			return pageNum-PAGE_NUM/2;	
		return 1;
	}
	public int getEndPage(){
		int res = getStartPage()+PAGE_NUM-1;
		if(res<maxPage)
		return res;
		return maxPage;
	}
	public int getLastPage(){
		if(pageNum>1){
			return pageNum-1;
		}
		return 1;
	}
	public int getNextPage(){
		if(pageNum<maxPage){
			return pageNum+1;
		}
		return maxPage;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getRowsNum() {
		return rowsNum;
	}
	public void setRowsNum(int rowsNum) {
		this.rowsNum = rowsNum;
	}
	public int getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}
	public int getRowsPerPage() {
		return rowsPerPage;
	}
	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}
	

}
