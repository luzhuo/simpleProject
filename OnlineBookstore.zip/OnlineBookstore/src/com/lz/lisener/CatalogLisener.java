package com.lz.lisener;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.lz.Dao.CatalogDao;
import com.lz.entily.CatalogBean;
import com.lz.util.DaoFactory;

public class CatalogLisener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		ServletContext application = arg0.getServletContext();
		application.removeAttribute("cataList");
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		ServletContext application = arg0.getServletContext();
		CatalogDao cDao = DaoFactory.getCatalogDao();
		try {
			List<CatalogBean> clist = cDao.getAllCatalog();
			application.setAttribute("cataList", clist);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
