package com.lz.lisener;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class TimeLisener implements Filter{
	public TimeLisener(){
		System.out.println("ʱ����������á�������");
	}
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)arg0;
		String url = request.getRequestURI().toString();
		long long1 = System.currentTimeMillis();
		arg2.doFilter(arg0, arg1);
		long long2 = System.currentTimeMillis();
		System.out.println("����"+url+"��ʱ"+(long2-long1)+"ms");
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
