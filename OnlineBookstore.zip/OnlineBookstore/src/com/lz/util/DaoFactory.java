package com.lz.util;

import com.lz.Dao.BookDao;
import com.lz.Dao.CatalogDao;
import com.lz.Dao.UserDao;
import com.lz.Dao.Impl.BookDaoImpl;
import com.lz.Dao.Impl.CatalogDaoImpl;
import com.lz.Dao.Impl.UserDaoImpl;

public class DaoFactory {
	private DaoFactory(){
		
	}
	public static BookDao getBookDao(){
		return new BookDaoImpl();
	}
	public static CatalogDao getCatalogDao(){
		return new CatalogDaoImpl();
	}
	public static UserDao getUserDao(){
		return new UserDaoImpl();
	}

}
