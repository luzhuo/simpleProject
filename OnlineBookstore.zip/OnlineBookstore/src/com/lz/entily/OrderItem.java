package com.lz.entily;

import java.io.Serializable;

public class OrderItem implements Serializable{
	private static final long serialVersionUID = 4194570525818803434L;

	private Long id;
	private BookBean book = new BookBean();
	private int num;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public BookBean getBook() {
		return book;
	}
	public void setBook(BookBean book) {
		this.book = book;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	} 
}
