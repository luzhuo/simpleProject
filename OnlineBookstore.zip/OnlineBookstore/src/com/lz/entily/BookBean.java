package com.lz.entily;

import java.io.Serializable;

public class BookBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -598918132199158342L;
	private Long id;
	private String book;
	private String pic;
	private String explain;
	private double price;
	private CatalogBean catalog = new CatalogBean();
	private AuthorBean author = new AuthorBean();
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public CatalogBean getCatalog() {
		return catalog;
	}
	public void setCatalog(CatalogBean catalog) {
		this.catalog = catalog;
	}
	public AuthorBean getAuthor() {
		return author;
	}
	public void setAuthor(AuthorBean author) {
		this.author = author;
	}
	
	

}
