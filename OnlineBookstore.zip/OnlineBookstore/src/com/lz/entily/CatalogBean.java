package com.lz.entily;

import java.io.Serializable;

public class CatalogBean implements Serializable{

	private static final long serialVersionUID = 1L;
	private Long id;
	private String catalog;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCatalog() {
		return catalog;
	}
	public void setName(String catalog) {
		this.catalog = catalog;
	}
}
