package com.lz.entily;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class OrderBean implements Serializable {
	private static final long serialVersionUID = -2970408558880157918L;
	
	private Long id;
	private UserBean user = new UserBean();
	private Long tel;
	private String address;
	private String info;
	private Double allPrice;
	private Date date;
	private Set<OrderItem> item = new HashSet<OrderItem>();
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public UserBean getUser() {
		return user;
	}
	public void setUser(UserBean user) {
		this.user = user;
	}
	public Long getTel() {
		return tel;
	}
	public void setTel(Long tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Double getAllPrice() {
		return allPrice;
	}
	public void setAllPrice(Double allPrice) {
		this.allPrice = allPrice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Set<OrderItem> getItem() {
		return item;
	}
	public void setItem(Set<OrderItem> item) {
		this.item = item;
	}

	
}
