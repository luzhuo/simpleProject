package com.lz.action;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class BaseAction extends HttpServlet {
       
	/**
	 * 
	 */
	private static final long serialVersionUID = -2327420133793437563L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if(action == null||action.trim().length()<1){
			action="list";
		}
		try {
			@SuppressWarnings("rawtypes")
			Class clz = this.getClass();
			@SuppressWarnings("unchecked")
			Method method = clz.getMethod(action,HttpServletRequest.class,HttpServletResponse.class);
			method.invoke(this, request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public abstract void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ;
}
