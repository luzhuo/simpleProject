package com.lz.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lz.Dao.BookDao;
import com.lz.domain.ShopCart;
import com.lz.entily.BookBean;
import com.lz.util.DaoFactory;

public class CartAction extends BaseAction{
	private static final long serialVersionUID = 6790211569172027490L;

	private BookDao bookDao = DaoFactory.getBookDao();

	public void refresh(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String[] sid = request.getParameterValues("id");
		String[] snum = request.getParameterValues("num");
		HttpSession session = request.getSession();
		Object object = session.getAttribute("mycart");
		ShopCart cart=null;
		if(object!=null&object instanceof ShopCart)
		cart =(ShopCart)object;
		if(sid!=null&&sid.length>0&&cart!=null)			
		for (int i = 0; i < sid.length; i++) {
			String id = sid[i];
			String num = snum[i];
			Long ids = null;
			Integer nums = null;
			try {
				ids = Long.valueOf(id);
				nums = Integer.valueOf(num);
			} catch (Exception e) {
				ids=null;
				nums =null;
				System.out.println("refresh����ת���쳣");
			}
			if(ids!=null&&nums!=null){
				cart.refresh(ids,nums);
			}
		}
		response.sendRedirect("cart.do");
		
		
		
	}
	public void clear(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ShopCart cart = new ShopCart();
		HttpSession session = request.getSession();
		Object obj = session.getAttribute("mycart");
		if(obj!=null&&obj instanceof ShopCart){
			cart=(ShopCart)obj;
		cart.clear();
		}
		response.sendRedirect("cart.do");
		
	}
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/cart/list.jsp").forward(request, response);
	}
	public void buy(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//System.out.println("buy����ִ��");
		ShopCart cart = new ShopCart();
		HttpSession session = request.getSession();
		Object obj = session.getAttribute("mycart");
		if(obj!=null&&obj instanceof ShopCart)
			cart=(ShopCart)obj;
		String sid=request.getParameter("id");
		Long id=null;
		try {
				id=Long.parseLong(sid);
				if(id!=null){
				BookBean book = bookDao.load(id);
				if(book!=null){
					cart.add(book);
				}				
				}
			} catch (Exception e) {
				id=null;
				System.out.println("����ת���쳣");
		}
		session.setAttribute("mycart", cart);
		//response.sendRedirect(request.getContextPath()+"/book/info.jsp");
		response.sendRedirect("cart.do");
	}

}
