package com.lz.action;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class PicAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int width,height;
	private String source ;
    public PicAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BufferedImage buffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics g= buffer.getGraphics();
		g.setColor(Color.white);
		g.fillRect(0, 0, width,height);//�߿�
		g.setColor(Color.black);
		g.drawRect(0, 0, width-5, height-2);
		g.setColor(Color.red);
		g.setFont(new Font("����",Font.BOLD,22));
		String checkcode = this.generateCheckCode(6);
		HttpSession session = request.getSession();
		session.setAttribute("checkcode", checkcode);
		g.drawString(checkcode,5, height-3);
		g.dispose();
		
		response.resetBuffer();
		response.setContentType("image/jpeg");
		response.setHeader("pragma", "no-cache");
		response.setHeader("cache-contro1", "no-cache");
		response.setDateHeader("expires",0);
		ServletOutputStream os = response.getOutputStream();
		ImageIO.write(buffer, "jpg", os);
		os.flush();
		os.close();
		
	}
	public String generateCheckCode(int len){
		char[] res = new char[len];
		Random rd = new Random();
		for (int i = 0; i < res.length; i++) {
			res[i]=source.charAt(rd.nextInt(source.length()));
		}
		return new String(res);
	}
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		String s1= config.getInitParameter("width");
		String s2= config.getInitParameter("height");
		try {
			width = Integer.parseInt(s1.trim());
			height = Integer.parseInt(s2.trim());
		} catch (Exception e) {
			width=60;
			height=20;
		}
		String ss = config.getInitParameter("source");
			if(ss!=null&&ss.trim().length()>0)
			source = ss.trim();
	
		
	}

}
