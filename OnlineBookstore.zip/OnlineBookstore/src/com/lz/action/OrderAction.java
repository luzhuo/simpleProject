package com.lz.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lz.util.StringUtil;

public class OrderAction extends BaseAction{
	private static final long serialVersionUID = 1L;
       
    public OrderAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/service/list.jsp").forward(request, response);
		
		
	}
	
	public void insert(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String tel = request.getParameter("tel");
		String info = request.getParameter("info");
		Map<String,String> err = new HashMap<String,String>();
		if(StringUtil.isBlank(name)){
			err.put("NoName","�ռ��˲���Ϊ��");
		}
		if(StringUtil.isBlank(address)){
			err.put("NoAddress","�ռ��˵�ַ����Ϊ��");
		}
		if(StringUtil.isBlank(tel)){
			err.put("NoTel","�ռ�����ϵ�绰����Ϊ��");
		}
		if(StringUtil.isBlank(info)){
			err.put("Noinfo","����д�ʼ�˵��");
		}
		if(!err.isEmpty()){
			request.setAttribute("errors", err);
			request.getRequestDispatcher("/service/list.jsp").forward(request, response);;
			return;
		}
		
		
		
	}

}
