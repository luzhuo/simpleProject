package com.lz.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lz.Dao.UserDao;
import com.lz.entily.UserBean;
import com.lz.util.DaoFactory;
import com.lz.util.StringUtil;

public class UserAction extends BaseAction{
	private static final long serialVersionUID = 1L;
	private UserDao userDao= DaoFactory.getUserDao();
	
	
	
	public void exit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath()+"/book.do");
		
	}

	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String checkcode = request.getParameter("checkcode");
		String url = request.getParameter("url");
		
		Map<String,String> errs= new HashMap<String,String>();
		HttpSession session = request.getSession();
		if(StringUtil.isBlank(username))
			errs.put("NoUser", "�û�������Ϊ��");
			
		if(StringUtil.isBlank(password))
			errs.put("NoPassword", "���벻��Ϊ��");
			
		if(StringUtil.isBlank(checkcode)){
			errs.put("NoCheckCode", "��֤�벻��Ϊ��");	
			}else{
			Object obj = session.getAttribute("checkcode");
			//System.out.println(obj+ "and"+checkcode);
			if(!checkcode.equals(obj)){
				errs.put("NoCheckCode", "��֤���������!");
				}
			session.removeAttribute("checkcode");
		}
		
		if(!errs.isEmpty()){
			session.setAttribute("errors", errs);
			session.setAttribute("user", username);
			//request.getRequestDispatcher("/user/login.jsp").forward(request, response);//����ת��
			response.sendRedirect(url);
			return;
		}
		UserBean user = new UserBean();
		user.setPassword(password);
		user.setUsername(username);
		try {
			boolean bb= userDao.login(user);
			if(bb){
				session.setAttribute("useruser", user);
			}else{
				errs.put("NotUserOrPass", "�û��������������");
				session.setAttribute("errors", errs);
			}
			response.sendRedirect(url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(user.getUsername());
			
	}
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
