package com.lz.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lz.Dao.BookDao;
import com.lz.Dao.CatalogDao;
import com.lz.domain.PageBean;
import com.lz.entily.BookBean;
import com.lz.entily.CatalogBean;
import com.lz.util.DaoFactory;

public class BookAction extends BaseAction {
	private static final long serialVersionUID = 1L;
     private BookDao bookDao = DaoFactory.getBookDao();
     private CatalogDao catalogDao = DaoFactory.getCatalogDao();
     
	private int rowsPerPage = 15;
    
	public void detail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String ss = request.getParameter("id");
		Long id=null;
		try {
			id = Long.parseLong(ss.trim());
			BookBean book = bookDao.load(id);
			request.setAttribute("book",book);
			
			request.getRequestDispatcher("/books/detail.jsp").forward(request, response);;
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	@SuppressWarnings("rawtypes")
	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Object obj = this.getServletContext().getAttribute("catalogList");
		if(obj==null||((List)obj).size()<1){//ֻ����ص�һ���Ժ�Ͳ����ٴν���
			try {
				List<CatalogBean> list = catalogDao.getAllCatalog();
				this.getServletContext().setAttribute("catalogList",list);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		String scid = request.getParameter("cid");
		Long catalogId =null;
		BookBean book = new BookBean();
		try {
			catalogId=Long.parseLong(scid);
			book.getCatalog().setId(catalogId);
			CatalogBean catalog = catalogDao.load(catalogId);
			if(catalog!=null)
				request.setAttribute("catalog", catalog);
		
		} catch (Exception e) {
			catalogId=null;
		}
		String keyword = request.getParameter("keyword");
		if(keyword!=null&&keyword.length()>0){
			keyword=new String(keyword.trim().getBytes("iso8859-1"),"GBK");
			request.setAttribute("keyword",keyword.trim());
			//System.out.println(keyword);
			book.setBook("%"+keyword.trim()+"%");}
		PageBean pages = new PageBean();
		pages.setRowsPerPage(rowsPerPage);//��ҳ�д������
		request.setAttribute("pages",pages);//����ҳ��
		String spage = request.getParameter("page");//��ȡҳ�����
		int pageNum=0;
		try{
			pageNum = Integer.parseInt(spage);//ת��Ϊ���õķ�ҳ����
		}catch(Exception e){
			//���ת���������Զ�����ֵ
			pageNum = 1;
		}
		pages.setPageNum(pageNum);//�������pageBean��
		try {
			//׼�����ݴ����Ĵ�Χ
			List<BookBean> blist = bookDao.getByBook(book,pages);
			
			request.setAttribute("booklist",blist);
			//��תҳ��
			request.getRequestDispatcher("/books/list.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	public void init(ServletConfig config) throws ServletException {
		super.init(config);//ԭ���Ĺ������ɿ���
		String ss = config.getInitParameter("rowsPerPage");//��ȡweb.xml�����õ�ֵ  ��ǿ��ת��
		try {
			rowsPerPage = Integer.parseInt(ss.trim());
		} catch (Exception e) {
			rowsPerPage = 15;
		}
	}

}
