package com.lz.Dao;

import java.util.List;

import com.lz.domain.PageBean;
import com.lz.entily.BookBean;

public interface BookDao {
	public List<BookBean> getByBook(BookBean book,PageBean pages) throws Exception;

	public BookBean load(Long id) throws Exception;

}
