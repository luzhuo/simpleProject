package com.lz.Dao;

import com.lz.entily.OrderBean;

public interface OrderDao {
	public Long insert(OrderBean order) throws Exception;
}
