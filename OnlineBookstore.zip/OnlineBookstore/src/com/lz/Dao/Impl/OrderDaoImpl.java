package com.lz.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.lz.Dao.OrderDao;
import com.lz.entily.OrderBean;
import com.lz.util.ConnectionManager;

public class OrderDaoImpl implements OrderDao{

	public Long insert(OrderBean order) throws Exception {
		
		Long id = null;
		Connection conn = null;
		PreparedStatement ps =null;
		ResultSet rs = null;
		try {
			conn = ConnectionManager.getConn();			
			conn.setAutoCommit(false);//ȡ���Զ��ύ
			String sql = "insert into b_order() values ()";//������в�����ϸ��Ϣ��
			
			ps.setLong(1, order.getUser().getId());//```
			ps.setString(2, order.getUser().getUsername());
			ps.setString(3, order.getUser().getAddress());
			ps.setLong(4, order.getUser().getPhone());
			//ps.setString(5, );
			//ps.setString(6, x);
			//ps.setString(7, x);
			ps.executeUpdate();
			sql="select seq_order.currval from dual";//�ող����idֵ
			ps = conn.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next()){
				id=rs.getLong(1);
			}
			sql="insert into ";//������ϸ��
			conn.commit();
		} catch (Exception e) {
			conn.rollback();
			id=null;
		}finally{
			ConnectionManager.close(conn, ps, rs);
		}
		return id;
	}

}
