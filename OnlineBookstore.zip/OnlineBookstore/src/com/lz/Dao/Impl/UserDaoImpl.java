package com.lz.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.lz.Dao.UserDao;
import com.lz.entily.UserBean;
import com.lz.util.ConnectionManager;

public class UserDaoImpl implements UserDao {

	@Override
	public boolean login(UserBean user) throws Exception {
		boolean res = false;
		Connection conn = ConnectionManager.getConn();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try {
			conn = ConnectionManager.getConn();
			String sql="select * from t_user where name=? and password=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			rs=ps.executeQuery();
			while(rs.next()){
				user.setAddress(rs.getString("address"));
				user.setAge(rs.getString("age"));
				user.setPhone(rs.getLong("phone"));
				res=true;
			}
		}finally{
			ConnectionManager.close(conn, ps, rs);
		}	
		return res;
	}

}
