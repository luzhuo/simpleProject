package com.lz.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lz.Dao.BookDao;
import com.lz.domain.PageBean;
import com.lz.entily.BookBean;
import com.lz.util.ConnectionManager;

public class BookDaoImpl implements BookDao{

	public List<BookBean> getByBook(BookBean book, PageBean pages)
			throws Exception {
		StringBuilder sql = new StringBuilder
("select b.*,c.name catalog,a.name from t_books b left join b_catalog c on b.catalog_id=c.id left join b_author a on b.author_id=a.id where 1=1");
		if(book!=null){
			if(book.getId()!=null)
			sql.append(" and b.id=").append(book.getId());
			if(book.getBook()!=null)
				sql.append(" and book like '").append(book.getBook()).append("'");
			if(book.getCatalog()!=null&&book.getCatalog().getId()!=null)
				sql.append(" and c.id=").append(book.getCatalog().getId());
		}
		List<BookBean> res = new ArrayList<BookBean>();
		Connection conn = null;
		PreparedStatement ps= null;
		ResultSet rs = null;
		try {
			conn = ConnectionManager.getConn();
			if(pages!=null&&pages.getRowsPerPage()>0){			
				ps=conn.prepareStatement(sql.toString(),ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
				rs= ps.executeQuery();
				if(pages.getPageNum()<1){
					pages.setPageNum(1);
				}
				if(pages.getMaxPage()<1){
					rs.last();
					int rowsNum = rs.getRow();//��ȡ����
					if(rowsNum<1)
						return res;
						int MaxPage = (rowsNum-1+pages.getRowsPerPage())/pages.getRowsPerPage();
						pages.setRowsNum(rowsNum);
						pages.setMaxPage(MaxPage);
				}
					
					if(pages.getPageNum()>pages.getMaxPage())
						pages.setPageNum(pages.getMaxPage());
						int begin = (pages.getPageNum()-1)*pages.getRowsPerPage()+1;
						rs.absolute(begin);					
						int kk =0;
					do{
						//��bookbean��ֵ
						if(++kk>pages.getRowsPerPage()){
							break;
						}
						BookBean temp = new BookBean();
						temp.getAuthor().setId(rs.getLong("author_id"));
						temp.getAuthor().setName(rs.getString("name"));
						temp.setBook(rs.getString("book"));
						temp.getCatalog().setId(rs.getLong("catalog_id"));
						temp.getCatalog().setName(rs.getString("catalog"));
						temp.setExplain(rs.getString("explain"));
						temp.setPic(rs.getString("pic"));
						temp.setPrice(rs.getDouble("price"));
						temp.setId(rs.getLong("id"));
						res.add(temp);
					}while(rs.next());
					
		}else{
			ps = conn.prepareStatement(sql.toString());
			rs = ps.executeQuery();
			while(rs.next()){
				BookBean temp = new BookBean();
				temp.getAuthor().setId(rs.getLong("author_id"));
				temp.getAuthor().setName(rs.getString("name"));
				temp.setBook(rs.getString("book"));
				temp.getCatalog().setId(rs.getLong("catalog_id"));
				temp.getCatalog().setName(rs.getString("catalog"));
				temp.setExplain(rs.getString("explain"));
				temp.setPic(rs.getString("pic"));
				temp.setPrice(rs.getDouble("price"));
				temp.setId(rs.getLong("id"));
				res.add(temp);
			}
			}
			
		} finally{
			ConnectionManager.close(conn,ps,rs);
		}
		
		return res;
	}

	public BookBean load(Long id) throws Exception{
		//System.out.println("load����ִ��");
		BookBean res = new BookBean();
		res.setId(id);
			List<BookBean> list = this.getByBook(res, null);
			if(list!=null&&list.size()>0)
					return list.get(0);					
		return res;
	}

}
