package com.lz.Dao;

import com.lz.entily.UserBean;

public interface UserDao {
	public boolean login(UserBean user) throws Exception;

}
