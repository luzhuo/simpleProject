package com.lz.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.lz.entity.StudentBean;

public class Test {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Configuration configure = new Configuration().configure();
		StandardServiceRegistry build = new StandardServiceRegistryBuilder().applySettings(configure.getProperties()).build();
		SessionFactory sf = configure.buildSessionFactory(build);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		StudentBean student = new StudentBean();
		student.setAddress("����");
		student.setAge("12");
		student.setId(44L);
		student.setPassword("1111");
		student.setName("����");
		student.setGrade("����");
		student.setIdCard("1111");
		student.setInfo("û��˵��");
		student.setSchool("һ�꼶");
		student.setMark("07151030");
		
		session.save(student);
		tx.commit();
		session.close();
		
	}

}
