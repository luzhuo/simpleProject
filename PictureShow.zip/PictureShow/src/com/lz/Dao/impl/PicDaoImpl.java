package com.lz.Dao.impl;

import com.lz.Dao.PictureDao;

public class PicDaoImpl implements PictureDao{

}
