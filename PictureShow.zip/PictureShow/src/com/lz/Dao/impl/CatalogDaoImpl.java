package com.lz.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.lz.Dao.CatalogDao;
import com.lz.entily.CatalogBean;
import com.lz.util.ConnectionManager;

public class CatalogDaoImpl implements CatalogDao {

	@Override
	public List<CatalogBean> getAllCatalog() throws Exception {
		List<CatalogBean> list = new ArrayList<CatalogBean>();
		Connection conn = ConnectionManager.getConn();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try{
			ps = conn.prepareStatement("select * from l_catalog");
			rs=ps.executeQuery();
			while(rs.next()){
				CatalogBean c = new CatalogBean();
				c.setId(rs.getLong("id"));
				c.setTitle(rs.getString("title"));
				list.add(c);
				
			}
	}finally{
			ConnectionManager.close(conn, ps, rs);
		}
		return list;
	}

	@Override
	public CatalogBean load(Long CatalogId) throws Exception {
		
		CatalogBean c = new CatalogBean();
		Connection conn = ConnectionManager.getConn();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try{
			ps = conn.prepareStatement("select * from l_catalog where id = "+CatalogId);
			rs=ps.executeQuery();
			if(rs.next()){
				c.setId(rs.getLong("id"));
				c.setTitle(rs.getString("title"));
			}
			
	}finally{
			ConnectionManager.close(conn, ps, rs);
		}
		return c;
	}

}
