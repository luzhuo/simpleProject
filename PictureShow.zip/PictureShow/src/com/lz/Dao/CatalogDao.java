package com.lz.Dao;

import java.util.List;

import com.lz.entily.CatalogBean;

public interface CatalogDao {
	public List<CatalogBean> getAllCatalog() throws Exception;
	public CatalogBean load(Long CatalogId) throws Exception;

}
