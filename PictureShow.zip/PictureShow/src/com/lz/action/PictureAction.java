package com.lz.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class PictureAction extends BaseAction{

	private static final long serialVersionUID = -1192332306208909230L;

	public void list(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
	}

}
