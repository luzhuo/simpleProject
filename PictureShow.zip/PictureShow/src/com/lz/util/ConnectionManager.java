package com.lz.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionManager {
//	public static void main(String[] args) throws Exception {
//		System.out.println(ConnectionManager.getConn());
//	}
	private ConnectionManager(){
		
	}
	private static Properties ps = new Properties();
	static{
		loadPs();
	}
	private static void loadPs(){
		if(ps!=null){
			try {
				InputStream is = ConnectionManager.class.getResourceAsStream("database.properties");
				ps.load(is);
				Class.forName(ps.getProperty("driver"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public static Connection getConn() throws Exception{
		
		String url = ps.getProperty("url");
		String name = ps.getProperty("name");
		String passwd = ps.getProperty("passwd");
		return DriverManager.getConnection(url, name, passwd);
	}
	
	public static void close(Connection conn,PreparedStatement ps,ResultSet rs){
		if(conn!=null){
			try {
				ps.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
