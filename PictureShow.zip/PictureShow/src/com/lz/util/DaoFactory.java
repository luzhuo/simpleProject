package com.lz.util;

import com.lz.Dao.CatalogDao;
import com.lz.Dao.PictureDao;
import com.lz.Dao.impl.CatalogDaoImpl;
import com.lz.Dao.impl.PicDaoImpl;

public class DaoFactory {
	public static CatalogDao getCatalogDao(){
		return new CatalogDaoImpl();
	}

	public static PictureDao getPicDao(){
		return new PicDaoImpl();
	}
}
