package com.lz.entily;

import java.io.Serializable;

public class PictureBean implements Serializable{

	private static final long serialVersionUID = -1244036546320800530L;
	private Long id;
	private String name;
	private String address;
	private CatalogBean catalog = new CatalogBean();
	private AuthorBean author = new AuthorBean();
	private String expalain;
	private Long hit;//�����
	private Long collect;//�ղ���
	private Long download;//������
	private int wide;
	private int length;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public CatalogBean getCatalog() {
		return catalog;
	}
	public void setCatalog(CatalogBean catalog) {
		this.catalog = catalog;
	}
	public AuthorBean getAuthor() {
		return author;
	}
	public void setAuthor(AuthorBean author) {
		this.author = author;
	}
	public String getExpalain() {
		return expalain;
	}
	public void setExpalain(String expalain) {
		this.expalain = expalain;
	}
	public Long getHit() {
		return hit;
	}
	public void setHit(Long hit) {
		this.hit = hit;
	}
	public Long getCollect() {
		return collect;
	}
	public void setCollect(Long collect) {
		this.collect = collect;
	}
	public Long getDownload() {
		return download;
	}
	public void setDownload(Long download) {
		this.download = download;
	}
	public int getWide() {
		return wide;
	}
	public void setWide(int wide) {
		this.wide = wide;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	
}
